#!/bin/sh

##### Rapuma KYUM Test/Example Script #####
# By Dennis Drescher (sparkycbr at gmail dot com)
# Last edited: 29.03.2016

# This script is for testing the Rapuma publishing system. For a more
# detailed explanation of commands used, refer to the totorial document
# (File: KYUM_Example_Totorial.odt). This will give information on how
# to set up the test environment so the commands below will work.
#
# NOTE: This script is desined to work with Rapuma version v0.7.202 or
# higher and on the Linux operating system, Ubuntu 14.04 or higher.

## ENVIONMENT SETUP
# There is a zip file that contains all the data and resources
# needed to create a publishing project. For this example, that file
# is kyu-mymr-kyum.zip When extracted, the name of the folder should
# be the project ID. The following variable needs to be set to the
# project ID:

# This is the language code. Can be taken from standards like ISO
# or IETF codes.
${LCID="kyu"}

# Now add a script or writing system code.
${SCID="mymr"}

# Now we will combine the LCID & SCID with a project identifier to create
# the PROJID used though out the script.
${PROJID=$LCID"-"$SCID"-kyum"}

# The file needs to be unzipped in a place on your system. Then
# set this variable to represent that location (do not add the 
# project ID or trailing path slash character):

${RESOURCE="/home/dennis/Publishing/my_source"}

# This sets the final path, do not edit
${PJHOME=$RESOURCE"/"$PROJID}

# Set the path to the cloud (off site storage like Dropbox)
${CLOUD="/home/dennis/Publishing/my_cloud"}

# This allows the command to be echoed
set -v


## PROJIDECT REMOVAL (For a clean start)
rapuma publication $PROJID project remove


## CREATING A PROJIDECT
rapuma publication $PROJID project create

## ADDING/REMOVING GROUPS
rapuma content $PROJID group add      --group GOSPEL      --comp_type usfm
rapuma content $PROJID group remove   --group GOSPEL
rapuma content $PROJID group add      --group 4TEES       --comp_type usfm
rapuma content $PROJID group add      --group GOSPEL      --comp_type usfm
rapuma content $PROJID group add      --group FRONT       --comp_type pdf

## PROJIDECT SETTINGS: Set some important values
rapuma setting $PROJID project        --section ProjectInfo   --key languageCode  --value $LCID
rapuma setting $PROJID project        --section ProjectInfo   --key scriptCode    --value $SCID

## ASSET MANAGEMENT: Macros, Fonts, and Preprocess scripts
# Macros
rapuma asset $PROJID macro add        --path $PJHOME/updates/usfmTex_20160312.zip   --component_type usfm
rapuma asset $PROJID macro remove     --component_type usfm
rapuma asset $PROJID macro add        --path $PJHOME/macros/usfmTex_20150225.zip    --component_type usfm
rapuma asset $PROJID macro update     --path $PJHOME/updates/usfmTex_20160312.zip   --component_type usfm

# Fonts
rapuma asset $PROJID font add         --path $PJHOME/fonts/Charis\ SIL_4.106.zip    --component_type usfm
rapuma asset $PROJID font add         --path $PJHOME/fonts/Padauk_2.701.zip         --component_type usfm
rapuma asset $PROJID font remove      --package_id "Charis SIL_4.106"
rapuma asset $PROJID font update      --path $PJHOME/fonts/Padauk_2.701.zip
# Scripts
rapuma asset $PROJID script add       --group GOSPEL      --path $PJHOME/KYUM/process/kyum_textPreprocess.py    --preprocess
rapuma asset $PROJID script update    --group GOSPEL      --path $PJHOME/updates/kyum_textPreprocess-v2.py      --preprocess
# Turn on preprocessing
rapuma setting $PROJID project        --section Groups/GOSPEL     --key usePreprocessScript   --value True
# Hyphenation
rapuma asset $PROJID hyphenation add
rapuma asset $PROJID hyphenation remove
rapuma asset $PROJID hyphenation add      --path $PJHOME/hyphenation
rapuma asset $PROJID hyphenation update   --path $PJHOME/updates

## ADDING/REMOVING/UPDATING COMPONENTS IN GROUPS
rapuma content $PROJID component add      --group GOSPEL  --cid_list "mat luk jhn"    --path $PJHOME/PT-source
rapuma content $PROJID component add      --group GOSPEL  --cid_list "act mrk"        --path $PJHOME/PT-source
rapuma content $PROJID component remove   --group GOSPEL  --cid_list act
rapuma content $PROJID component add      --group 4TEES   --cid_list "1th 2th 1ti 2ti" --path $PJHOME/PT-source
rapuma content $PROJID component update   --group GOSPEL  --cid_list jhn              --path $PJHOME/updates
rapuma content $PROJID component add      --group FRONT   --cid_list "cover title copyright toc introduction" --path $PJHOME/FRONT-source
rapuma content $PROJID component remove   --group FRONT   --cid_list "cover"
rapuma content $PROJID component update   --group FRONT   --cid_list "title"          --path $PJHOME/updates

## ASSET MANAGEMENT: Macros and Fonts
# Illustrations
rapuma asset $PROJID illustration add     --group GOSPEL  --path $PJHOME/illustrations
rapuma asset $PROJID illustration remove  --group GOSPEL  
rapuma asset $PROJID illustration add     --group GOSPEL  --path $PJHOME/illustrations
rapuma asset $PROJID illustration update  --group GOSPEL  --path $PJHOME/updates

## SETTINGS
# Bind order
rapuma setting $PROJID project            --section Groups/FRONT      --key bindingOrder          --value 1
rapuma setting $PROJID project            --section Groups/GOSPEL     --key bindingOrder          --value 2
rapuma setting $PROJID project            --section Groups/4TEES      --key bindingOrder          --value 3
# General
rapuma setting $PROJID macro              --section Macros/usfmTex_20160312/TeXBehavior --key vFuzz     --value 4.8pt
# Illustrations
rapuma setting $PROJID project            --section Groups/GOSPEL     --key useIllustrations      --value True
rapuma setting $PROJID layout             --section DocumentFeatures  --key useFigurePlaceHolders --value False
rapuma setting $PROJID illustration       --section GOSPEL/lb00135    --key position --value br
# Font
rapuma setting $PROJID font               --section GeneralSettings   --key useRenderingSystem    --value GR
rapuma setting $PROJID font               --section GeneralSettings   --key useLanguage           --value $LCID
rapuma setting $PROJID font               --section GeneralSettings   --key useMapping            --value kye_renumber
rapuma setting $PROJID layout             --section TextElements      --key bodyFontSize          --value 9
rapuma setting $PROJID layout             --section TextElements      --key bodyTextLeading       --value 13
# Print output
rapuma setting $PROJID layout             --section DocumentFeatures  --key backgroundComponents  --value watermark,cropmarks
rapuma setting $PROJID layout             --section DocumentFeatures  --key watermarkText         --value "TESTING"
rapuma asset $PROJID background update    --group GOSPEL
rapuma setting $PROJID layout             --section DocumentFeatures  --key docInfoText           --value "Rapuma Test Render"
# Columns
rapuma setting $PROJID layout             --section DocumentFeatures  --key columnGutterRule      --value True
rapuma setting $PROJID macro              --section Macros/usfmTex_20160312/Columns --key columnGutterFactor        --value 20
rapuma setting $PROJID macro              --section Macros/usfmTex_20160312/Columns --key columnGutterRuleSkip      --value 4
# Verse number display
rapuma setting $PROJID macro              --section Macros/usfmTex_20160312/ChapterVerse --key useMarginalVerses    --value True
# Binding
rapuma setting $PROJID project            --section Groups/4TEES      --key startPageNumber                         --value 274
# Footnotes
rapuma setting $PROJID macro              --section Macros/usfmTex_20160312/Footnotes --key defineFootnoteRule      --value "\hrule height 2pt\smallskip"
rapuma setting $PROJID macro              --section Macros/usfmTex_20160312/Footnotes --key footnoteRuleOn          --value "[config:macroConfig|Macros|[self:macPackId]|Footnotes|defineFootnoteRule]"
# Hyphenation
rapuma setting $PROJID project            --section Groups/4TEES      --key useHyphenation        --value True
rapuma setting $PROJID project            --section Groups/GOSPEL     --key useHyphenation        --value True
rapuma setting $PROJID project            --section ProjectInfo       --key hyphenationOn         --value True
# Project meta-data
rapuma setting $PROJID project            --section ProjectInfo       --key projectDescription    --value "Some New Testament Scripture in an Asian language"
rapuma setting $PROJID project            --section ProjectInfo       --key typesetters           --value "Johannes Gutenberg"
rapuma setting $PROJID project            --section ProjectInfo       --key translators           --value "John Wycliffe"
rapuma setting $PROJID project            --section ProjectInfo       --key projectTitle          --value "Some Asian New Testament Scripture"
rapuma setting $PROJID project            --section ProjectInfo       --key creatorID             --value Johannes

## RENDERING
# Turn off PDF viewing to avoid screen clutter
rapuma setting $PROJID project            --section Managers/usfm_Xetex --key pdfViewerCommand    --value "none"

# Component Level
rapuma process $PROJID component render   --group GOSPEL --cid_list jhn --background --doc_info   --save

# Group Level
rapuma process $PROJID group render       --group GOSPEL
rapuma process $PROJID group render       --group 4TEES
rapuma process $PROJID group render       --group FRONT

# Turn on PDF viewing so we can see the final results (this returns to the original default setting)
rapuma setting $PROJID project            --section Managers/usfm_Xetex --key pdfViewerCommand    --value "default"

# Bind the results
rapuma process $PROJID project bind       --save --background --doc_info

# Sharing with the cloud
# Start clean
rm -rf      $CLOUD
mkdir -p    $CLOUD
# Run share commands
rapuma publication $PROJID share push     --path $CLOUD
rapuma publication $PROJID share pull     --path $CLOUD
rapuma publication $PROJID share push     --path $CLOUD   --replace
rapuma publication $PROJID share pull     --path $CLOUD   --replace



