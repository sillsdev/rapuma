#!/usr/bin/python
# -*- coding: utf_8 -*-

# This is an example post processing script for the NOD PUB-THAI-ACT project

###############################################################################
############################## Setup Environment ##############################
###############################################################################

import os, sys, shutil, subprocess

# Set the RPM base program path
rpmHome = os.environ.get('RPM_BASE')
if not rpmHome :
    rpmHome = os.path.join('usr', 'share', 'rpm')
    os.environ['RPM_BASE'] = rpmHome

# Set our paths to the RPM resources we might need
sys.path.insert(0, os.path.join(rpmHome, 'python_lib', 'rpm', 'core'))

from tools import *

###############################################################################
############################## Post Process Code ##############################
###############################################################################

# This should be done with proper Python code but instead we will call out
# to Perl just to see what happens.

source = sys.argv[1]
tempFile = source + '.tmp'
bakFile = source + '.bak'
# Make backup file
shutil.copy(source, bakFile)
# Make temp file
shutil.copy(source, tempFile)

# Build a command tuple and add documentation for each command

commands = (

    # 01 Thai-Lanna opening double quotes
    # SearchText=<< (U+003C)
    # ReplaceText=\u201c
    ('perl', '-CSD', '-i', '-pe',  r's/<</“/g', tempFile),

    # 02 Thai-Lanna closing double quotes
    # SearchText=>> (U+003E)
    # ReplaceText=\u201d
    ('perl', '-CSD', '-i', '-pe',  r's/>>/”/g', tempFile),

    # 03 Thai-Lanna opening single quotes
    # SearchText=<
    # ReplaceText=\u2018
    ('perl', '-CSD', '-i', '-pe',  r's/</‘/g', tempFile),

    # 04 Thai-Lanna closing single quotes
    # SearchText=>
    # ReplaceText=\u2019
    ('perl', '-CSD', '-i', '-pe',  r's/>/’/g', tempFile),

    # 05 Thai-Lanna remove / following opening double quote
    # SearchText=\u201c/
    # ReplaceText=\u201c
    ('perl', '-CSD', '-i', '-pe',  r's/“\//“/g', tempFile),

    # 06 Thai-Lanna remove / preceding double closing quote
    # SearchText=/\u201d
    # ReplaceText=\u201d
    ('perl', '-CSD', '-i', '-pe',  r's/\/”/”/g', tempFile),

    # 07 Thai-Lanna remove / following single opening quote
    # SearchText=\u2018/
    # ReplaceText=\u2018
    ('perl', '-CSD', '-i', '-pe',  r's/‘\//‘/g', tempFile),

    # 08 Thai-Lanna remove / preceding single closing quote
    # SearchText=/\u2019
    # ReplaceText=\u2019
    ('perl', '-CSD', '-i', '-pe',  r's/\/’/’/g', tempFile),

    # 09 Thai-Lanna remove / after opening bracket
    # SearchText=\u0028/
    # ReplaceText=\u0028
    ('perl', '-CSD', '-i', '-pe',  r's/\(\//\(/g', tempFile),

    # 10 Thai-Lanna remove / preceding closing bracket
    # SearchText=/\u0029
    # ReplaceText=\u0029
    ('perl', '-CSD', '-i', '-pe',  r's/\/\)/\)/g', tempFile),

    # 11 Thai-Lanna change/ into ZWSP
    # SearchText=\u002F
    # ReplaceText=\u200B (turn off 'r' and use Unicode IDs)
    ('perl', '-CSD', '-i', '-pe', 's/\\x{002F}/\\x{200B}/g', tempFile),

    # 13 Thai-Lanna remove space before double closing quote
    # SearchText=\s\u201D
    # ReplaceText=\u201D
    ('perl', '-CSD', '-i', '-pe',  r's/ ”/”/g', tempFile),

    # 14 Thai-Lanna add NBSP between single and double quote
    # SearchText=\u2019\u201D
    # ReplaceText=\u2019\u00A0\u201D
    ('perl', '-CSD', '-i', '-pe',  r's/’”/’ ”/g', tempFile),

    # 15 Thai-Lanna change \sc to \zxt
    # SearchText=sc
    # ReplaceText=zxt
    ('perl', '-CSD', '-i', '-pe',  r's/\\sc/\\zxt/g', tempFile)

    )

# Run the command tuple
good = 0
cmd = 0
for c in commands :
    cmd +=1
    if subprocess.call(c) == 0 :
        good +=1

# Finish by copying out the results to the working text file
shutil.copy(tempFile, source)
# Take out the trash
os.remove(tempFile)


# Return "0" if successful
sys.exit(cmd - good)


