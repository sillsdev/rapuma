#!/bin/sh

# Set Vars:
input_file="$1"
output_file="$2"
temp_file="$2.tmp"

cp $input_file $temp_file

echo 'processing: ' $input_file



##########################################################################################
# Search and Replace

# Perl command line replacements for this project

# Example line:
# perl -CSD -i -pe 's/(a)(b)/\2\1/g;' *.txt

# Let's unpack the command line options:

# -CSD use Unicode on input and output
# -i do inplace file replacement (you could also do -i.bak to get .bak files of the originals)
# -pe is really two options. -p says to iterate over every line in the file and print the result of your actions to the output. -e is followed by the perl code to execute within the loop.

##########################################################################################
# Library of commands used on this project

# 01 Thai-Lanna opening double quotes
# SearchText=<< (U+003C)
# ReplaceText=\u201c
perl -CSD -i -pe 's/\x{003C}\x{003C}/\x{201C}/g;' $temp_file

# 02 Thai-Lanna closing double quotes
# SearchText=>> (U+003E)
# ReplaceText=\u201d
perl -CSD -i -pe 's/\x{003E}\x{003E}/\x{201D}/g;' $temp_file

# 03 Thai-Lanna opening single quotes
# SearchText=<
# ReplaceText=\u2018
perl -CSD -i -pe 's/\x{003C}/\x{2018}/g;' $temp_file

# 04 Thai-Lanna closing single quotes
# SearchText=>
# ReplaceText=\u2019
perl -CSD -i -pe 's/\x{003E}/\x{2019}/g;' $temp_file

# 05 Thai-Lanna remove / following opening double quote
# SearchText=\u201c/
# ReplaceText=\u201c
perl -CSD -i -pe 's/\x{201C}\x{002F}/\x{201C}/g;' $temp_file

# 06 Thai-Lanna remove / preceding double closing quote
# SearchText=/\u201d
# ReplaceText=\u201d
perl -CSD -i -pe 's/\x{002F}\x{201D}/\x{201D}/g;' $temp_file

# 07 Thai-Lanna remove / following single opening quote
# SearchText=\u2018/
# ReplaceText=\u2018
perl -CSD -i -pe 's/\x{2018}\x{002F}/\x{2018}/g;' $temp_file

# 08 Thai-Lanna remove / preceding single closing quote
# SearchText=/\u2019
# ReplaceText=\u2019
perl -CSD -i -pe 's/\x{002F}\x{2019}/\x{2019}/g;' $temp_file

# 09 Thai-Lanna remove / after opening bracket
# SearchText=\u0028/
# ReplaceText=\u0028
perl -CSD -i -pe 's/\x{0028}\x{002F}/\x{0028}/g;' $temp_file

# 10 Thai-Lanna remove / preceding closing bracket
# SearchText=/\u0029
# ReplaceText=\u0029
perl -CSD -i -pe 's/\x{002F}\x{0029}/\x{0029}/g;' $temp_file

# 11 Thai-Lanna change/ into ZWSP
# SearchText=\u002F
# ReplaceText=\u200B
perl -CSD -i -pe 's/\x{002F}/\x{200B}/g;' $temp_file

# 13 Thai-Lanna remove space before double closing quote
# SearchText=\s\u201D
# ReplaceText=\u201D
perl -CSD -i -pe 's/\s\x{201D}/\x{201D}/g;' $temp_file

# 14 Thai-Lanna add NBSP between single and double quote
# SearchText=\u2019\u201D
# ReplaceText=\u2019\u00A0\u201D
perl -CSD -i -pe 's/\x{2019}\x{201D}/\x{2019}\x{00A0}\x{201D}/g;' $temp_file

# 15Thai-Lanna change \sc to \zxt
# SearchText=sc
# ReplaceText=zxt
perl -CSD -i -pe 's/\x{005C}sc/\x{005C}zxt/g;' $temp_file

# Manual tweaks:

# 16 Thai-Lanna move single NBSP double quote after \f* before \f +
# SearchText=\f\*\u2019\u00A0\u201D
# ReplaceText= Manually cut the sequence \u2019\u00A0\u201D and paste it directly before the \f marker

# 17 Thai-Lanna move double quote before \f* before \f +
# SearchText=\f\*\u201D
# ReplaceText= Manually cut \u201D and paste it directly before the \f marker


# Change the file to the real output name
cp $temp_file $output_file

# Clean up temp file
rm $temp_file


