#!/bin/sh

# Command for rendering the KYU-MYMR-MRK test project

# Render the MRK component
rapuma component KYU-MYMR-MRK usfm mrk -e 

