#!/bin/sh

# Command for rendering the KYU-MYMR-MRK test project

# Render the MRK component
rpm component KYU-MYMR-MRK usfm mrk -e 

