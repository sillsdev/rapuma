#!/bin/sh

# Commands for modifying and ajusting settings in the KYU-MYMR-MRK test project

# Adjust exsisting settings (configuration/section/key/value)
rpm settings KYU-MYMR-MRK usfm_Layout Fonts lineSpacingFactor 1.08
rpm settings KYU-MYMR-MRK usfm_Layout Fonts fontSizeUnit .95pt

rpm settings KYU-MYMR-MRK usfm_Layout Columns bodyColumns 2
rpm settings KYU-MYMR-MRK usfm_Layout Columns columnGutterFactor 10
rpm settings KYU-MYMR-MRK usfm_Layout Columns columnShift 5.3
rpm settings KYU-MYMR-MRK usfm_Layout Columns columnGutterRuleSkip 4
rpm settings KYU-MYMR-MRK usfm_Layout Columns columnGutterRule True

rpm settings KYU-MYMR-MRK usfm_Layout HeaderFooter useRunningHeaderRule False
rpm settings KYU-MYMR-MRK usfm_Layout HeaderFooter headerPosition 0.75
rpm settings KYU-MYMR-MRK usfm_Layout HeaderFooter runningHeaderRulePosition 4
rpm settings KYU-MYMR-MRK usfm_Layout HeaderFooter footerPosition 0.12

rpm settings KYU-MYMR-MRK usfm_Layout PageLayout pageSizeCode UBS60
rpm settings KYU-MYMR-MRK usfm_Layout PageLayout pageWidth 145
rpm settings KYU-MYMR-MRK usfm_Layout PageLayout pageHeight 210

#rpm settings KYU-MYMR-MRK usfm_Layout ChapterVerse useMarginalVerses True
rpm settings KYU-MYMR-MRK usfm_Layout ChapterVerse afterVerseSpaceFactor 4
rpm settings KYU-MYMR-MRK usfm_Layout ChapterVerse afterChapterSpaceFactor ""

rpm settings KYU-MYMR-MRK usfm_Layout Crossreferences autoCallerListCrossrefs "①,②,③,④,⑤,⑥,⑦,⑧,⑨,⑩,⑪,⑫,⑬,⑭,⑮,⑯,⑰,⑱,⑲,⑳"
rpm settings KYU-MYMR-MRK usfm_Layout Crossreferences paragraphedCrossrefs True
rpm settings KYU-MYMR-MRK usfm_Layout Crossreferences pageResetCallersCrossrefs True

rpm settings KYU-MYMR-MRK usfm_Layout Footnotes defineFootnoteRule "\hrule height 0.4pt\smallskip"
rpm settings KYU-MYMR-MRK usfm_Layout Footnotes autoCallerListFootnotes "Ⓐ,Ⓑ,Ⓒ,Ⓓ,Ⓔ,Ⓕ,Ⓖ,Ⓗ,Ⓘ,Ⓙ,Ⓚ,Ⓛ,Ⓜ,Ⓝ,Ⓞ,Ⓟ,Ⓠ,Ⓡ,Ⓢ,Ⓣ,Ⓤ,Ⓥ,Ⓦ,Ⓧ,Ⓨ,Ⓩ"
#rpm settings KYU-MYMR-MRK usfm_Layout Footnotes autoCallerListFootnotes "ⓐ,ⓑ,ⓒ,ⓓ,ⓔ,ⓕ,ⓖ,ⓗ,ⓘ,ⓙ,ⓚ,ⓛ,ⓜ,ⓝ,ⓞ,ⓟ,ⓠ,ⓡ,ⓢ,ⓣ,ⓤ,ⓥ,ⓦ,ⓧ,ⓨ,ⓩ"
rpm settings KYU-MYMR-MRK usfm_Layout Footnotes autoCallerStartCharacter Ⓐ
rpm settings KYU-MYMR-MRK usfm_Layout Footnotes autoCallerMaxCharacterNumbers 20
rpm settings KYU-MYMR-MRK usfm_Layout Footnotes paragraphedFootnotes True
rpm settings KYU-MYMR-MRK usfm_Layout Footnotes pageResetCallersFootnotes True

rpm settings KYU-MYMR-MRK usfm_Layout TeXBehavior hFuzz 1pt
rpm settings KYU-MYMR-MRK usfm_Layout TeXBehavior vFuzz 4.3pt

rpm settings KYU-MYMR-MRK project "Managers/usfm_Font" useLanguage kyu
rpm settings KYU-MYMR-MRK project "Managers/usfm_Font" useMapping kye_renumber
rpm settings KYU-MYMR-MRK project "Managers/usfm_Font" useRenderingSystem GR
rpm settings KYU-MYMR-MRK font "Fonts/Charis SIL_4.106/UsfmTeX/SecondaryFont" charissiltitle "\font\charissiltitle = \"[^^path^^/CharisSILR.ttf]\" at 18pt"
rpm settings KYU-MYMR-MRK font "Fonts/Charis SIL_4.106/UsfmTeX/SecondaryFont" callerfont "\font\callerfont = \"[^^path^^/CharisSILR.ttf]\" at 8pt"

# Add custom styles
rpm style KYU-MYMR-MRK usfm main -a -f -p "../resources/bible-format.sty"
#rpm style KYU-MYMR-MRK usfm custom -a -f -p "../resources/custom.sty"
# Testing install of default custom style file
rpm style KYU-MYMR-MRK usfm custom -a

# Add/overwrite project files with special ones
rpm install KYU-MYMR-MRK ../resources/mrk.adj ../KYU-MYMR-MRK/Components/mrk -f
rpm install KYU-MYMR-MRK ../resources/hyphenation.tex ../KYU-MYMR-MRK/Hyphenation -f
#rpm install KYU-MYMR-MRK ../resources/mrk.piclist ../KYU-MYMR-MRK/Components/mrk





