#!/bin/sh

# Commands for modifying and ajusting settings in the KYU-MYMR-MRK test project.
# Except for a few, these are mostly RPM terminal commands.

# Note that because some commands use relative path setting, this script needs
# to be executed from the scripts folder. Elsewhere, it will fail.

# Adjust exsisting settings (configuration/section/key/value)
rpm settings KYU-MYMR-MRK usfm_Layout Fonts lineSpacingFactor 1.0871
rpm settings KYU-MYMR-MRK usfm_Layout Fonts fontSizeUnit .95pt

# Column Settings
rpm settings KYU-MYMR-MRK usfm_Layout Columns bodyColumns 2
rpm settings KYU-MYMR-MRK usfm_Layout Columns columnGutterFactor 10
rpm settings KYU-MYMR-MRK usfm_Layout Columns columnShift 5.3
rpm settings KYU-MYMR-MRK usfm_Layout Columns columnGutterRuleSkip 4
rpm settings KYU-MYMR-MRK usfm_Layout Columns columnGutterRule True

# Page settings
rpm settings KYU-MYMR-MRK usfm_Layout PageLayout pageSizeCode UBS60
rpm settings KYU-MYMR-MRK usfm_Layout PageLayout pageWidth 145
rpm settings KYU-MYMR-MRK usfm_Layout PageLayout pageHeight 210

# Chapter Verse settings
rpm settings KYU-MYMR-MRK usfm_Layout ChapterVerse useMarginalVerses True
rpm settings KYU-MYMR-MRK usfm_Layout ChapterVerse afterVerseSpaceFactor 4
rpm settings KYU-MYMR-MRK usfm_Layout ChapterVerse afterChapterSpaceFactor ""

# Footnote settings
rpm settings KYU-MYMR-MRK usfm_Layout Footnotes defineFootnoteRule "\hrule height 0.4pt\smallskip"
rpm settings KYU-MYMR-MRK usfm_Layout Footnotes autoCallerListFootnotes "\kern0.2em *\kern0.4em"
rpm settings KYU-MYMR-MRK usfm_Layout Footnotes paragraphedFootnotes True
rpm settings KYU-MYMR-MRK usfm_Layout Footnotes omitCallerInFootnotes True

# Extra settings
rpm settings KYU-MYMR-MRK usfm_Layout TeXBehavior hFuzz 1pt
rpm settings KYU-MYMR-MRK usfm_Layout TeXBehavior vFuzz 4.3pt
rpm settings KYU-MYMR-MRK project usfm_Illustration useIllustrations True

# Font settings
rpm settings KYU-MYMR-MRK font "Fonts/Charis SIL_4.106/UsfmTeX/SecondaryFont" charissiltitle "\font\charissiltitle = \"[^^path^^/CharisSILI.ttf]\" at 10pt"
rpm settings KYU-MYMR-MRK font "Fonts/Charis SIL_4.106/UsfmTeX/SecondaryFont" callerfont "\font\callerfont = \"[^^path^^/CharisSILR.ttf]\" at 8pt"
rpm settings KYU-MYMR-MRK project "Managers/usfm_Font" useLanguage kyu
rpm settings KYU-MYMR-MRK project "Managers/usfm_Font" useMapping kye_renumber
rpm settings KYU-MYMR-MRK project "Managers/usfm_Font" useRenderingSystem GR

# Header Content settings
rpm settings KYU-MYMR-MRK usfm_Layout HeaderContent runningHeaderOddRight lastref
rpm settings KYU-MYMR-MRK usfm_Layout HeaderContent runningHeaderOddCenter pagenumber
rpm settings KYU-MYMR-MRK usfm_Layout HeaderContent runningHeaderEvenLeft firstref
rpm settings KYU-MYMR-MRK usfm_Layout HeaderContent runningHeaderEvenCenter pagenumber
rpm settings KYU-MYMR-MRK usfm_Layout HeaderFooter useRunningHeaderRule False
rpm settings KYU-MYMR-MRK usfm_Layout HeaderFooter headerPosition 0.75
rpm settings KYU-MYMR-MRK usfm_Layout HeaderFooter runningHeaderRulePosition 4
rpm settings KYU-MYMR-MRK usfm_Layout HeaderFooter footerPosition 0.12

# Add custom styles
rpm style KYU-MYMR-MRK usfm main -a -f -p "../resources/bible-format.sty"
rpm style KYU-MYMR-MRK usfm custom -a -f -p "../resources/custom.sty"

# Add/overwrite default project files with special ones
rpm install KYU-MYMR-MRK ../resources/mrk.adj ../KYU-MYMR-MRK/Components/mrk -f
rpm install KYU-MYMR-MRK ../resources/xetex_settings_usfm-ext.tex ../KYU-MYMR-MRK/Macros


# Illustrations
# Once illustrations are implemented, the following RPM command will need
# to be run to output Illustrations in the project:

#    rpm install KYU-MYMR-MRK ../resources/mrk.piclist ../KYU-MYMR-MRK/Illustrations -f


# Hyphenation:
# Unfortunately, this project does not use real TeX hyphenation rules, but
# instead, uses a hyphenation exception word list of an unusually large size.
# To enable hyphenation for this particular language, you first must be sure
# that the maximum number of words allowed in the hyphenation exceptions list
# is set high enough in the right TeX configuration file. The following
# instructions will accomplish this, open the following file with:

#    sudo gedit /etc/texmf/texmf.d/95NonPath.cnf

# Near the bottom you will find hyph_size = 8191. That's a lot but for this
# project you need more. You need to increase it to: 13001 (Note this is a
# prime number, this setting only takes prime numbers.) This is slightly more
# than the actual number of words in the exception list used for this project.

# Once you have changed the setting you will need to save your file and close
# the editor so the terminal is free. The next step is to remake the main
# texmf.cnf. To do this, run this command:

#    sudo update-texmf

# Then just to be safe you should probably run this too to update the fmt files
# (I think, either way, it doesn't seem to hurt):

#    fmtutil --refresh

# Your new settings should be recognized by TeX.

# Finally, you need to set the project up to use hyphenation. That requires the
# following two RPM commands:

#    rpm settings KYU-MYMR-MRK project usfm_Hyphenation useHyphenation True
#    rpm install KYU-MYMR-MRK ../resources/hyphenation.tex ../KYU-MYMR-MRK/Hyphenation -f

# Now, hyphenation should be applied to the text on the next rendering. However,
# it may be difficult to see because no visible hyphen character is used.



