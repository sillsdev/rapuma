#!/usr/bin/python
# -*- coding: utf_8 -*-


###############################################################################
############################## Setup Environment ##############################
###############################################################################

import os, sys, shutil

# Set the RPM base program path
rpmHome = os.environ.get('RPM_BASE')
if not rpmHome :
    rpmHome = os.path.join('usr', 'share', 'rpm')
    os.environ['RPM_BASE'] = rpmHome

# Set our paths to the RPM resources we might need
sys.path.insert(0, os.path.join(rpmHome, 'python_lib', 'rpm', 'core'))

from tools import *

###############################################################################
############################## Post Process Code ##############################
###############################################################################

source = sys.argv[1]
tempFile = source + '.tmp'
bakFile = source + '.bak'
# Make backup and temp file
shutil.copy(source, bakFile)

# Read in the source file
contents = codecs.open(source, "rt", encoding="utf_8_sig").read()

# Insert a chapter lable marker so we have centered chapter numbers
contents = re.sub(ur"(\\c\s1\r\n)", ur"\\cl \u200b\n\1", contents)

# To overcome a bug in the Palaso USFM parser we need to put in all
# \ft markers that it strips out when we use pprint on import
#contents = re.sub(ur"(?u)(fr\s[0-9]+:[0-9]+\s)", ur"\1\\ft ", contents)

codecs.open(tempFile, "wt", encoding="utf_8_sig").write(contents)

# Finish by copying the tempFile to the source
if not shutil.copy(tempFile, source) :
    # Take out the trash
    os.remove(tempFile)
    sys.exit(0)
else :
    terminal('\nSCRIPT: Error: Failed to copy: [' + tempFile + '] to: [' + source + ']')


