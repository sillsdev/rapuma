# Tai Dam orthography conversion
# Written by Jim Brase, SIL International, 2006-2009
#            jim_brase@sil.org
# Copyright SIL International 2006
##########################################################################
# History:
# ***************************************************************************************
# VERSION 2.0.0
#   Converted from PUA to Unicode for Tai Viet script
#   Fixed bug in XML parsing which had restricted WorldPad-formatted ini files to one
#   writing system per line.
# Version 1.4.3 beta -- Not released.
#   Changed default Tone Class Marker to Latin Small Letter Saltillo
# Version 1.4.2 beta -- Not released.
#   Changed the end-of-program report for the Typo Count.
# Version 1.4.1
#   ** Release version used by Tai Dam language project 2007-2009**
#   Add sign on message with version number.
#   Implement improved error reporting and SignOff function.
#   Implement use of delimited literals in punctuation and spelling exceptions dictionary.
#   Implement new structure for user defined punctuation dictionary to use LexItem class.
#   Add TestINI routine.
# Version 1.4.0 alpha
#   Implement parsing of XML-formatted ini file, so that ini files can be edited
#   with WorldPad.
# Version 1.3.2
#   Corrected conversion of VN /-ak/ into TD vAA + loKo.
# Version 1.3.1
#   Corrected TD reduplication
# Version 1.3.0:
#   Corrected the handling of footnote markers and other inline SFMs. Create
#   functions FindEndMarker() and FindEndBoundary() for this purpose.
# Version 1.2.0:
#   Improves the Spelling Exceptions Dictionary with LexItem class.
# Version 1.1.0:
#   Implements conversion to Tai Script using PUA codes in the E000 block (since SIL
#   has reserved the F000 block for corporate use).
#   Tai Script code points are defined using a Python dictionary, to make
#   it easier to edit the code points in the future.
#   Implement several new ini file variables. See the ini file.
# Version 1.0.0:
#   Implements conversion to Lao
#   Implements conversion to Tai script using PUA codes in the F000 block.
##########################################################################

import string
import os
import sys
import codecs
import unicodedata

# GLOBAL VARIABLES:

Version = "2.0.0"

TYPO  = u'\ufffd'   # Flags a typo in the source text
TypoCount = 0       # Counts the typos in the source text
TCM   = u'\uA78C'   # Tone Class Marker = Latin Small Letter Saltillo
ACUTE = u'\u0301'   # Combining Acute Accent
HOOK = u'\u0309'    # Combining Hook Above
DOT = u'\u0323'     # Combining Dot Below
SBH = u'\u2011'     # Syllable-Break Hyphen, usually the Non-Breaking Hyphen, marks
                    # syllable breaks in loan words and proper names.
NBSP = u'\u00A0'    # No-Break Space
UseMaiNueng = 0     # indicates type of TD tone marks to use:
                    #   1 = use spacing tone marks (mNUENG, mSONG)
                    #   0 = use combining tone marks (mEK, mTHO)
LastLaoWord = u""   # stores last Lao word for comparison with current word; when a match
                    # is made, the Lao reduplication mark will be inserted in place of
                    # the current word.
LastTdWord = u""    # stores last Tai Dam word for comparison with current word; when a 
                    # match is made, the Tai Dam reduplication mark will be inserted in 
                    # place of the current word.
LastBoundary = u""  # used for comparison in control of reduplication mark

# Program control flags:
target = "both"     # indicates which is the target script to convert to: lao, taidam, or both.
CommandLineHasTarget = False
                    # indicates that the target alphabets are specified on the command line
doLao = 1           # indicates conversion to Lao
doTD = 1            # indicates conversion to Tai Dam
doIniTest = False   # indicates the testIniFlag was specified on the command line. 
iniType = "-txt"    # indicates whether the INI file uses txt or wpx format.

# Command line arguments:
iniFlag = "-i"      # indicates that the next argument is the name of the INI file. 
wpxFlag = "-wpx"    # indicates that the INI file will be in WorldPad wpx format.
                    # Overrides the default .txt extension if no INI file name
                    # is specified. But if the command line contains an alternate
                    # INI file name, this flag is ignored.
targetFlag = "-t"   # indicates that the next argument identifies the target alphabet(s).
testIniFlag = '-test'
                    # indicates that the program should display the results of reading the
                    # command line and the INI file, and then exit.
IgnoredFields = ["\\id", ""]
                    # list of fields that should not be converted

Delim = "#&*'\""    # string delimeters for the punctuation and spelling exceptions dictionaries
##vnPunct = []
##tdPunct = []
##tdPad = []
##laoPunct = []
##laoPad = []
SpExLex = [ ]   # SpExLex is a list of class LexItem. It replaces the lists
                    # vnLex, laoLex, and tdLex used in v1.1.
PunctLex = [ ]  # PunctLex is a list of class LexItem.
laofile=0
tdfile=0

#Tai Script Dictionary:
ts = {}
ts['loKO'] = u"\uaa80"
ts['hiKO'] = u"\uaa81"
ts['loKW'] = u"\uaa80\uaaab"
ts['hiKW'] = u"\uaa81\uaaab"
ts['loKHO'] = u"\uaa82"
ts['hiKHO'] = u"\uaa83"
ts['loKHW'] = u"\uaa82\uaaab"
ts['hiKHW'] = u"\uaa83\uaaab"
ts['loKHHO'] = u"\uaa84"
ts['hiKHHO'] = u"\uaa85"
ts['loKHHW'] = u"\uaa84\uaaab"
ts['hiKHHW'] = u"\uaa85\uaaab"
ts['loGO'] = u"\uaa86"
ts['hiGO'] = u"\uaa87"
ts['loNGO'] = u"\uaa88"
ts['hiNGO'] = u"\uaa89"
ts['loNGW'] = u"\uaa88\uaaab"
ts['hiNGW'] = u"\uaa89\uaaab"
ts['loCO'] = u"\uaa8a"
ts['hiCO'] = u"\uaa8b"
ts['loCHO'] = u"\uaa8c"
ts['hiCHO'] = u"\uaa8d"
ts['loSO'] = u"\uaa8e"
ts['hiSO'] = u"\uaa8f"
ts['loNYO'] = u"\uaa90"
ts['hiNYO'] = u"\uaa91"
ts['loDO'] = u"\uaa92"
ts['hiDO'] = u"\uaa93"
ts['loTO'] = u"\uaa94"
ts['hiTO'] = u"\uaa95"
ts['loTHO'] = u"\uaa96"
ts['hiTHO'] = u"\uaa97"
ts['loNO'] = u"\uaa98"
ts['hiNO'] = u"\uaa99"
ts['loBO'] = u"\uaa9a"
ts['hiBO'] = u"\uaa9b"
ts['loPO'] = u"\uaa9c"
ts['hiPO'] = u"\uaa9d"
ts['loPHO'] = u"\uaa9e"
ts['hiPHO'] = u"\uaa9f"
ts['loFO'] = u"\uaaa0"
ts['hiFO'] = u"\uaaa1"
ts['loMO'] = u"\uaaa2"
ts['hiMO'] = u"\uaaa3"
ts['loYO'] = u"\uaaa4"
ts['hiYO'] = u"\uaaa5"
ts['loRO'] = u"\uaaa6"
ts['hiRO'] = u"\uaaa7"
ts['loLO'] = u"\uaaa8"
ts['hiLO'] = u"\uaaa9"
ts['loVO'] = u"\uaaaa"
ts['hiVO'] = u"\uaaab"
ts['loHO'] = u"\uaaac"
ts['hiHO'] = u"\uaaad"
ts['loO'] = u"\uaaae"
ts['hiO'] = u"\uaaaf"
ts['mKANG'] = u"\uaab0"
ts['vAA'] = u"\uaab1"
ts['vI'] = u"\uaab2"
ts['vUE'] = u"\uaab3"
ts['vU'] = u"\uaab4"
ts['vE'] = u"\uaab5"
ts['vO'] = u"\uaab6"
ts['mKHIT'] = u"\uaab7"
ts['vIA'] = u"\uaab8"
ts['vUEA'] = u"\uaab9"
ts['vUA'] = u"\uaaba"
ts['vAUE'] = u"\uaabb"
ts['vAY'] = u"\uaabc"
ts['vAN'] = u"\uaabd"
ts['vAM'] = u"\uaabe"
ts['vAP'] = u"\uaabe\uaa9a"
ts['mEK'] = u"\uaabf"
ts['mNUENG'] = u"\uaac0"
ts['mTHO'] = u"\uaac1"
ts['mSONG'] = u"\uaac2"
ts['symKON'] = u"\uaadb"
ts['symNUENG'] = u"\uaadc"
ts['symSAM'] = u"\uaadd"
ts['symHOHOI'] = u"\uaade"
ts['symKOIKOI'] = u"\uaadf"

##########################################
# Function definitions.
##########################################

def ReadComLine (a):
    # Analyze the command line arguements contained in list a.
    # Update the global variable target, and Return:
    #   ScriptPath: the home directory from which the script or exe is being run
    #   iniPath: any specified path of the INI file
    #   iniNameExt: the name and extension of the INI file
    #   inPath: the directory where the input file is located
    #   inName: the name of the input file (without the extension)
    #   inExt: the extension of the input file

    global iniType, doIniTest, target, doLao, doTD, CommandLineHasTarget
    
    count = len(a)
    iniSpec=""
    t=""
    inSpec=""

    # There should always be a ScriptPath.
    # a[0] is the full file specification for the script. Remove the
    # script file name and extension from it to get the ScriptPath
    ScriptPath = a[0][:a[0].rfind("\\")+1]

    i=1
    while i<count and inSpec=="":
        # if the arguement is the iniFlag, the next arguement is the
        # name of the INI file
        if a[i]==iniFlag:
            i=i+1
            iniSpec = a[i]
        # else if the arguement is the wpxFlag, set the iniSpec to equal
        # the wpxFlag. But ignore the wpxFlag if the iniSpec already has
        # a value.
        elif a[i]==wpxFlag:
            if iniSpec == "":
                iniSpec = wpxFlag
        # else if the arguement is the targetFlag, the next arguement
        # specifies the target alphabet(s)
        elif a[i]==targetFlag:
            i=i+1
            target = a[i]
            # Set flag to keep INI file from overwriting commandline target
            CommandLineHasTarget = True
        # else if the argument is the testIniFlag, set the doIniTest flag
        elif a[i] == testIniFlag:
            doIniTest = True
        # else the arguement is the specification of the input file
        else:
            inSpec = a[i]
        i=i+1

    # Evaluate the iniSpec -- INITIALIZATION FILE
    if iniSpec == "":
        iniPath = ""
        iniNameExt = "TDoc-ini.txt"
    elif iniSpec.lower() == wpxFlag:
        iniPath = ""
        iniNameExt = "TDoc-ini.wpx"
        iniType = wpxFlag
    else:
        if iniSpec.rfind("\\")==-1:
            iniPath = ""
            iniNameExt = iniSpec
        else:
            iniPath = iniSpec[:iniSpec.rfind("\\")+1]
            iniNameExt = iniSpec[iniSpec.rfind("\\")+1:]
        if iniNameExt.endswith('.wpx'):
            iniType=wpxFlag

    # Evaluate the inSpec -- INPUT FILE
    if inSpec == "":
        inPath = ""
        inName = ""
        inExt = ""
    else:
        if inSpec.rfind("\\")==-1:
            inPath = ""
            inNameExt = inSpec
        else:
            inPath = inSpec[:inSpec.rfind("\\")+1]
            inNameExt = inSpec[inSpec.rfind("\\")+1:]
            
        if inNameExt.rfind(".")==-1:
            inName = inNameExt
            inExt = ""
        else:
            inName = inNameExt[:inNameExt.rfind(".")]
            inExt  = inNameExt[inNameExt.rfind("."):]
    
    return (ScriptPath, iniPath, iniNameExt, inPath, inName, inExt)

def StripXML (xline):
    # strip any XML commands from xline, including leading spaces
    # throw away the ending return and/or newline
    # return the results

    l = len(xline)
    x=0
    line = u""

    # skip leading space:
    while x<l:
        if xline[x] <> u' ':
            break
        x=x+1
    while x<l:
        # look for an opening XML delimiter
        if xline[x] == u'<':
            # find the closing delimiter
            while x<l:
                if xline[x] == u'>' or xline[x] == u'\n':
                    x=x+1
                    break
                x=x+1
        else:
            if xline[x] == u'\r' or xline[x] == u'\n':
                break
            line = line+xline[x]
            x=x+1
    return(line)

def GetIniLine(inifile):
    # Read and return the next data line of the ini file

    EndFile = False
    # If the input is from an XML file:    
    if iniType==wpxFlag:
        # Build a data line consisting of plain text from XML input...
        line = ''
        # First search for the <Contents..> tag that marks the beginning of the data line.
        while True:
            line1 = unicodedata.normalize("NFD",inifile.readline())
            # Check for EOF
            if len(line1)==0:
                EndFile = True
                break
            # Stop search at start of <Contents..> or end of XML body.
            if line1.lower().count('<contents') or line1.lower().count('</body'):
                break
        # Did we find the <Contents..>?
        if line1.lower().count('<contents'):
            # Yes. Build the data line from successive input lines until </Contents..> tag is found.
            while True:
                # Read another input line
                line1 = unicodedata.normalize("NFD",inifile.readline())
                # Check for EOF
                if len(line1)==0:
                    EndFile = True
                    break
                # Stop at end of </Contents..> or end of XML body.
                if line1.lower().count('</contents') or len(line1)==0 or line1.lower().count('</body'):
                    break
                # Strip the XML code from the input line, and append any remaining text to the data line
                line = line + StripXML(line1)

    else:
        # Read a line of plain text
        line = unicodedata.normalize("NFD",inifile.readline())

    # Return the line
    return (line, EndFile)
    
def ReadIniFile(inifile):
    # Read the initialization file and load user defined globals

    global iniType, target, TYPO, TCM, SBH, NBSP, UseMaiNueng, PunctLex, SpExLex
    GoodINI = True
    GoodPunct = True
    GoodSpEx = True

##    # If the iniType is wpx, skip everything up to the beginning of the body.
##    if iniType==wpxFlag:
##        while 1:
##            line0 = unicodedata.normalize("NFD",inifile.readline())
##            if line0.lower().startswith('<body') or len(line0)==0:
##                break

    while True:
        # Read a line
        line1, EndFile = GetIniLine(inifile)
        # check for EOF
        if EndFile:
            break
#        print 'length of line1 = ', len(line1)
#        print 'line1 = "', line1, '"'
##        line0 = unicodedata.normalize("NFD",inifile.readline())
##        # line length of 0 indicates EOF
##        if len(line0)==0:
##            break
##        # if iniType is wpx, a line starting with '</body' indicates end of XML body.
##        if iniType==wpxFlag and line0.lower().startswith('</body'):
##            break
##        # if iniType is wpx, strip the XML code
##        if iniType==wpxFlag:
##            line1 = StripXML(line0)
##        else:
##            line1 = line0

        # If the first character is a BOM, skip it,
        # then strip off any remaining white space.
        if len(line1) > 0 and line1[0] == u'\uFEFF':
            line = line1[1:].strip()
        else:
            line = line1.strip()
        
        # If what is left is a blank line, ignore the line and go get another.
        if len(line)==0:
            continue

        # ignore comment lines
        if line.startswith("\\com"):
            continue

        # \target specifies the target alphabet(s),
        # but if target was specified on the command line, ignore it here.
        if line.startswith("\\target"):
            if CommandLineHasTarget:
                continue
            else:
                target = line[7:].strip()
                
        # \IgnoredFields specifies which fields of the input should be output
        # without any conversion
        elif line.startswith("\\IgnoredFields"):
            IdentifyIgnoredFields(line[14:])

        # \TypoFlag
        elif line.startswith("\\TypoFlag"):
            TYPO = GetUni(line, TYPO)
        
        # \TCM
        elif line.startswith("\\TCM"):
            TCM = GetUni(line, TCM)
        
        # \SBH
        elif line.startswith("\\SBH"):
            SBH = GetUni(line, SBH)
        
        # \NBSP
        elif line.startswith("\\NBSP"):
            NBSP = GetUni(line, NBSP)

        # \UseMaiKhitForA
        elif line.startswith("\\UseMaiKhitForA"):
            ts['mKANG'] = ts['mKHIT']

        # \UseMaiNueng
        elif line.startswith("\\UseMaiNueng"):
            UseMaiNueng = True
        
        # \Punctuation marks the beginning of the Punctuation dictionary
        elif line.startswith("\\punctuation"):
            PunctLex, GoodPunct = BuildLex(inifile)

        # \SpEx marks the beginning of the Spelling Exceptions Dictionary
        elif line.startswith("\\SpEx"):
            # Build the Spelling Exceptions lexicon, then return to main.
            SpExLex, GoodSpEx = BuildLex(inifile)
        
        # \EndIni marks the end of the ini file.
        elif line.startswith("\\EndIni"):
            break
        
        # An unrecognized line may be out of sequence or an invalid marker.
        else:
            GoodINI = False
            
    inifile.close()

    # Report any errors.    
    if not (GoodINI & GoodPunct & GoodSpEx):
        message = 'The INI file may be corrupt or a marker may be out of sequence.\n'
        if not GoodPunct:
            message = message + '   Errors found in Punctuation Dictionary.\n'
        if not GoodSpEx:
            message = message + '   Errors found in Spelling Exceptions Dictionary.\n'
        message = message + 'Please check the file.'
        SignOff ("INI file.")
        
    return()

def BuildLex(inifile):
    # Build the dictionary for the punctuation or spelling exceptions.
    
    global iniType, TYPO
    Lexicon = [ ]
    
    while True:
        # Read a line
        line1, EndFile = GetIniLine(inifile)
        # check for EOF
        if EndFile:
            break
##        line0 = unicodedata.normalize("NFD",inifile.readline())
##        # line length of 0 indicates EOF
##        if len(line0)==0:
##            break
##        # if iniType is wpx, a line starting with '</body' indicates end of XML body.
##        if iniType==wpxFlag and line0.lower().startswith('</body'):
##            break
##        # if iniType is wpx, strip the XML code
##        if iniType==wpxFlag:
##            line = StripXML(line0)
##        else:
##            line = line0

        # strip off any remaining leading or trailing space
        line = line1.strip()
        # ignore comments and blank lines.
        if len(line) == 0 or line.startswith('\\com'):
            continue
        # \EndPunctuation marks the end of the punctuation dictionary
        elif line.startswith("\\EndPunctuation"):
            break
        # \EndSpEx marks the end of the Spelling Exceptions dictionary
        elif line.startswith("\\EndSpEx"):
            break
        # \EndIni marks the end of the INI file
        elif line.startswith("\\EndIni"):
            break
        # \vn flags Vietnamese spelling or punctuation, and the beginning
        # of a new record.
        elif line.startswith("\\vn"):
            Word = ParseLexField(line[3:].strip())
            Lexicon = Lexicon + [ LexItem(Word) ]
        # \lao flags Lao spelling or punctuation
        elif line.startswith("\\lao"):
            if (Lexicon[-1].lao<>TYPO):
                print "WARNING:"
                print "  The following line in the Spelling Exceptions Dictionary of the"
                print "  INI file starts with \"\\lao\", but is out of sequence:"
                print "    ", line
                print "  This line will be ignored."
            else:
                Word = ParseLexField(line[4:].strip())
                Lexicon[-1].set_lao(Word)
        # \td flags Tai Dam spelling or punctuation
        elif line.startswith("\\td"):
            if (Lexicon[-1].td<>TYPO):
                print "WARNING:"
                print "  The following line in the Spelling Exceptions Dictionary of the"
                print "  INI file starts with \"\\td\", but is out of sequence:"
                print "    ", line
                print "  This line will be ignored."
            else:
                Word = ParseLexField(line[3:].strip())
                Lexicon[-1].set_td(Word)
        else:
            print "WARNING:"
            print "  The following line in the Spelling Exceptions Dictionary of the"
            print "  INI file does not start with \"\\vn\", \"\\td\", or \"\\lao\","
            print "  and cannot be identified."
            print "    ", line
            print "  This line will be ignored."

    # Now check the lexicon for errors
    valid = True
    MaxL = len(Lexicon)
    for L in range (0,MaxL):
        valid = valid and Lexicon[L].valid
##    if not(valid):
##        print
##        print "WARNING:"
##        print "  Errors were found the in the Spelling Exceptions Dictionary."
##        print "  Results of the conversion may be inaccurate."
##        print
    return(Lexicon, valid)

def ParseLiteral(line):
    # NEW FUNCTION WITH VERSION 1.4.1
    # 'line' starts with a literal string, which may then be followed by
    # other text. The first charcter of line is the opening delimeter.
    # Find the matching closing delimeter, and return the length of the
    # literal, excluding the delimeters.

    # Find the closing delimeter. The length of the undelimited line is
    # equal to the index of the closing delimeter, starting from line[1:]
    length = line[1:].find(line[0])
    # if the closing delimeter was not found...
    if length == -1:
        length = len(line[1:])
    return (length)

def ParseLexField(line):
    # NEW VERSION WITH VERSION 1.4.1  
    # 'line' consists of sequence of delimited literals and/or Unicode Scalar Values
    # in U+xxxx format. A semicolon (;) not enclosed in delimetes flags the rest of
    # the line as a comment. White space outside of delimeters is ignored. All
    # other non-white space text not enclosed within delimeters should be treated
    # as an error.
    # The leading format marker and leading and trailing whitespace (including
    # the newline) have already been stripped. Parse the remainder of the line
    # and return the phrase as a string of Unicode text.

    i = 0
    LineLength = len(line)
    uPhrase = u''
    LexFieldError = False
    # Parse line
    while i < LineLength:
        #  if the next character is a semicolon...
        if line[i] == u';':
            # skip the rest of the line.
            break
        # Else if the next character of the line is a delimeter...
        elif Delim.find(line[i]) > -1:
            # Parse the literal to find its length.
            length = ParseLiteral(line[i:])
            # length = the length of the literal excluding the delimeters
            # Append the literal to the Unicode phrase and increment i.
            uPhrase = uPhrase + line[i+1:i+1+length]
            i = i + 2 + length
        # Else if the next two characters are 'U+'...
        elif line[i:].upper().startswith(u'U+'):
            # Convert the USV to a Unicode character.
            length, c = ConvertUSVtoText (line[i:])
            # Append it to the Unicode phrase and increment i.
            if c == u'':
                LexFieldError = True
            else:
                uPhrase = uPhrase + c
            i = i + length
        # Else if the next character is white space...
        elif line[i].isspace():
            # skip it.
            i = i + 1
        # Else the next character is an error...
        else:
            # Set the error flag and skip this character.
            LexFieldError = True
            i = i + 1

    if LexFieldError:
        print 'WARNING, error found in INI file: ', line
        
    return (uPhrase)

def ConvertUSVtoText (line):
    # NEW WITH VERSION 1.4.1  
    # Line starts with a Unicode Scalar Value in U+xxxx notation (upper or lower
    # case letters). Return the length of the USV and the Unicode char it represents.

    # Segment the line at the first white space.
    Segment = line.split(None,1)
    length = len(Segment[0])
    
    if isHex(Segment[0][2:]):
        uChar = unichr(int(Segment[0][2:],16))
    else:
        print 'WARNING, error in INI file: \"', Segment[0], '\" is not a valid USV.'
        uChar = u''
    return (length, uChar)

##def ParseLexField(line):
##    # VERSION PRIOR TO 1.4.1  
##    # 'line' consists of a vernacular phrase in one of the scripts followed by an
##    # optional comment delimited by a semicolon. (The leading format marker and
##    # leading whitespace have already been stripped.) 
##    # Strip the the trailing comment, and any leading or trailing white
##    # space, then call the ParsePhrase function to analyze and return the phrase
##    # as a string of Unicode text.
##    
##    i = line.find(u';')
##    if (i==-1):
##        phrase = ParsePhrase(line)
##    else:
##        phrase = ParsePhrase(line[:i].strip())
##    return (phrase)

##def ParsePhrase(xPhrase):
##    # 'xPhrase' is a string consisting either of all Unicode text, a sequence of Unicode
##    # code points in U+xxxx notation enclosed in curly brackets, or a mixture of both.
##    # Convert the U+xxxx notation to Unicode text, and return the equivalent string
##    # as pure Unicode text.
##
##    # typical xPhrase structure:
##    # 0123456789012345678901234567890
##    # uni text{U+xxxx U+xxxx}uni text...
##    # |       |             |
##    # i(1)    j(1)
##    #         i(2)          j(2)
##    #                        i(3)... 
##
##    i = 0
##    uPhrase = u''
##    while 1:
##        if len(xPhrase[i:]) == 0:
##            break
##        if xPhrase[i] == u'{':
##            j = xPhrase[i:].find(u'}')
##            if j == -1:
##                j = i + len(xPhrase[i:])
##            uPhrase = uPhrase + ConvertCodePointsToText(xPhrase[i+1:j].upper())
##            if xPhrase[j] == u'}':
##                i = j + 1
##            else:
##                i = j
##        else:
##            j = xPhrase[i:].find(u'{')
##            if j == -1:
##                j = i + len(xPhrase[i:])
##            uPhrase = uPhrase + xPhrase[i:]
##            i = j
##    return (uPhrase)

##def ConvertCodePointsToText (CodeSpec):
##    # CodeSpec contains a string of Unicode code points in U+XXXX notation (upper case
##    # letters only). Code points are seperated by spaces. Convert the string of
##    # code points to Unicode text.
##
##    if CodeSpec.startswith(u'U+'):
##        i = 2
##    else:
##        i = 0
##    CodePoints = CodeSpec[i:].split(u'U+')
##    uText = u''
##    for c in CodePoints:
##        c = c.strip()
##        if isHex(c):
##            uText = uText + unichr (int(c,16))
##        else:
##            print "ERROR in Spelling Exceptions Dictionary:"
##            print "\'", c, "\' in \"", CodeSpec, "\" is not a hexidecimal number."
##            print "Data may not convert correctly."
##    return (uText)

def IdentifyIgnoredFields(line):
    # Identify which fields of the input file are to be left unchanged by the
    # conversion process, as specified by the \IgnoredFields control in the
    # INI file.
    global IgnoredFields
    # Split the line into words. Append an empty string to the end.
    IgnoredFields = line.split() + [""]
    # Add a '\' before each word.
    i=0
    while len(IgnoredFields[i]) > 0 :
        IgnoredFields[i] = "\\" + IgnoredFields[i]
        i=i+1
    return()

##def AnanlyzePunctuation(line):
##    # Determine what punctuation needs conversion
##    PunctSpecs = line.split()
##    i=0
##    count = len(PunctSpecs)
##    while i < count:
##        ParsePS(PunctSpecs[i])
##        i=i+1
##    return()

##def ParsePS(s):
##    # Parse the punctuation specification given in string s
##    global vnPunct, tdPunct, tdPad, laoPunct, laoPad
##    length = len(s)
##    # The minimum length of a good string is 5
##    if length < 5:
##        print "Warning: bad punctuation spec:", s
##        return()
##    # s[2] must be a digit
##    if not s[2].isdigit():
##        print "Warning: bad punctuation spec:", s
##        return()
##    # We will use the following indices:
##    #    Indices we know:
##    #       0 >> vnPunct
##    #       1 >> tdPunct
##    #       2 >> tdCount
##    #    Indices we must find:
##    #       tpc >> tdPadChar
##    #       lp >> laoPunct
##    #       lc >> laoCount
##    #       lpc >> laoPadChar
##
##    # find tpc: start at tdCount and increment until it reaches tdPadChar    
##    tpc=2
##    while tpc<length and s[tpc].isdigit():
##        tpc=tpc+1
##    if tpc >= length:
##        print "Warning: bad punctuation spec:", s
##        return()
##    # Check to see if tpc is pointing at a Uni Spec, then calculate lp
##    if s[tpc:].startswith("U+"):
##        if tpc+6>length or not isHex(s[tpc+2:tpc+6]):
##            print "Warning: bad punctuation spec:", s
##            return()
##        lp=tpc+6
##    # else there is no tdPadChar, and tpc is already point to loaPunct
##    else:
##        lp=tpc
##
##    # laoCount is one char past the laoPunct. It must be a digit.
##    lc = lp+1
##    if not s[lc].isdigit():
##        print "Warning: bad punctuation spec:", s
##        return()
##
##    # find lpc: start at laoCount and increment until it reaches laoPadChar
##    lpc=lc
##    while lpc < length and s[lpc].isdigit():
##        lpc=lpc+1
##    if lpc >= length:
##        print "Warning: bad punctuation spec:", s
##        return()
##    # Check to see if lpc is pointing at a Uni Spec
##    if s[lpc:].startswith("U+"):
##        if lpc+6>length or not isHex(s[lpc+2:lpc+6]):
##            print "Warning: bad punctuation spec:", s
##            return()
##    # else there is no laoPadChar
##
##    # Everything looks good -- Do it.
##    vnPunct = [s[0]] + vnPunct
##    if s[1]=='#':
##        tdPunct = [u""] + tdPunct
##    else:
##        tdPunct = [s[1]] + tdPunct
##    tdCount = int(s[2:tpc])
##    if tdCount == 0:
##        # No padding; ignore any tdPadChar
##        tdPad = [u""] + tdPad
##    else:
##        tdPadChar = unichr(int(s[tpc+2:tpc+6],16))
##        tdPad = [tdCount*tdPadChar] + tdPad
##    if s[lp]=='#':
##        laoPunct = [u""] + laoPunct
##    else:
##        laoPunct = [s[lp]] + laoPunct
##    laoCount = int(s[lc:lpc])
##    if laoCount == 0:
##        # No padding; ignore any laoPadChar
##        laoPad = [u""] + laoPad
##    else:
##        laoPadChar = unichr(int(s[lpc+2:lpc+6],16))
##        laoPad = [laoCount*tdPadChar] + laoPad
##
##    return()

def GetUni(s, u):
    # Parse string s and identify the first Unicode code point specified within it. 
    # The Unicode value should be specified with the "U+xxxx" syntax.
    # The parameter u identifies the fall back value which will be returned if no
    # valid Unicode code point is found in s.
    i = s.find("U+")
    if i == -1:
        print "Warning: Bad Unicode value specified in ini file:"
        print "         ", s
        return(u)
    if isHex(s[i+2:i+6])==0:
        print "Warning: Bad Unicode value specified in ini file:"
        print "         ", s
        return(u)
    return(unichr(int(s[i+2:i+6],16)))

def isHex(s):
    # Verify whether string s is all hex digits.
    length = len(s)
    s=s.lower()
    r = 1
    i=0
    while i<length:
        if ((s[i]>='0' and s[i]<='9') or (s[i]>='a' and s[i]<='f')):
            i=i+1
        else:
            r = 0
            break
    return(r)

##def IsPunct(c):
##    # Return true if character 'c' is punctuation, otherwise false
##    punctuation = '''!()-{}[]:;"',.?'''
##    if punctuation.find(c) > -1:
##        return (1)
##    else:
##        return (0)

def isIgnoredField(line):
    # Determine if the line is a field which should be ingnored.
    global IgnoredFields
    i=0
    while len(IgnoredFields[i]):
        if line.find(IgnoredFields[i])==0:
             return(1)
        i=i+1
    return(0)

def isVNalpha (c):
# Return True if c is a valid char in the Source Language orthography

    #define the alphabet
    SourceBasic = u'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    SourceAddOns = u'\u0110\u0111\u0301\u0302\u0306\u0309\u031B\u0323'
    #vnAlpha = string.ascii_letters + vnAddOns + TCM
    SourceAlpha = SourceBasic + SourceAddOns + TCM

##    print 'c =', ord(c)
##    print 'SourceAlpha =', SourceAlpha
##    print 'found =', SourceAlpha.find(c)
    if SourceAlpha.find(c) == -1:
        return(0)
    else:
        return(1)

############################
## Out of date version
##def CheckLex (vnWord):
##    # Check to see if the VN word is in the lexicon. If it is, return the
##    # corresponding Lao and TD words. If not, return empty strings.
##    LexLength = len (vnLex)
##    i=0
##    while i < LexLength:
##        if vnWord == vnLex[i]:
##            return (laoLex[i], tdLex[i])
##        elif vnLex[i]==u"":
##            return ("","")
##        i=i+1
##    return ("","")

def CheckSpExLex (vnWord):
    # Check to see if the VN word is in the Spelling Exceptions Dictionary.
    # If it is, return the corresponding Lao and TD words. 
    # If not, return empty strings.
    global SpExLex
    LexLength = len (SpExLex)
    for i in range (0, LexLength):
        if vnWord == SpExLex[i].vn:
            return (SpExLex[i].lao, SpExLex[i].td)
    return (u"", u"")

def GetToneNumber (w):
    # Analyze and return the tone of w.

    # Error check: there should be only one tone mark.
    if (w.find(ACUTE)>-1) + (w.find(HOOK)>-1) + (w.find(DOT)>-1) > 1:
        # Return -1 to mark the error.
        return (-1)
    
    if w[0] == TCM:
        if w.find(ACUTE) != -1:
            return (4)
        elif w.find(DOT) != -1:
            return (6)
        else:
            return (5)
    else:
        if w.find(ACUTE) != -1:
            return (2)
        elif w.find(HOOK) != -1:
            return (3)
        else:
            return (1)

def GetCi (w, tone):
    # Analyze the initial consonant of the VN word. Return:
    #   the initial consonant of the VN word
    #   the corresponding initial consonant of the Lao word
    #   the LaoTCM (tone class marker, Mai Catawa) if required
    #   the corresponding initial consonant of the Tai Dam word (not yet implemented)

    global TypoCount

    # INITIAL CONSONANT MAPPING TABLE.
    # Any leading VN Tone Class Marker has been stripped. A glottal stop has been appended
    # to the front of the VN word to simplify matching vowel initial syllables.
    # The Mai Catawa is U+0ECB. It is the LaoTCM for consonants that lack a tone 4-6 character.
    vnCi   = [ u"\u0294b", u"\u0294ch", u"\u0294c", u"\u0294d", u"\u0294\u0111", u"\u0294gi", u"\u0294h", u"\u0294kh",  u"\u0294k", u"\u0294l",      u"\u0294m", u"\u0294ngh",    u"\u0294ng",     u"\u0294nh",     u"\u0294n", u"\u0294ph", u"\u0294p", u"\u0294qu",     u"\u0294s", u"\u0294th", u"\u0294t", u"\u0294v",      u"\u0294" ]
    LaoCi1 = [ u"\u0e9a",  u"\u0e88",   u"\u0e81",  u"\u0ea2",  u"\u0e94",       u"\u0ea2",   u"\u0eab",  u"\u0e82",    u"\u0e81",  u"\u0eab\u0ebc", u"\u0edd",  u"\u0eab\u0e87", u"\u0eab\u0e87", u"\u0eab\u0e8d", u"\u0edc",  u"\u0e9d",   u"\u0e9b",  u"\u0e81\u0ea7", u"\u0eaa",  u"\u0e96",   u"\u0e95",  u"\u0eab\u0ea7", u"\u0ead" ]
    LaoCi4 = [ u"\u0e9a",  u"\u0e88",   u"\u0e81",  u"\u0ea2",  u"\u0e94",       u"\u0ea2",   u"\u0eae",  u"\u0e84",    u"\u0e81",  u"\u0ea5",       u"\u0ea1",  u"\u0e87",       u"\u0e87",       u"\u0e8d",       u"\u0e99",  u"\u0e9f",   u"\u0e9b",  u"\u0e81\u0ea7", u"\u0e8a",  u"\u0e97",   u"\u0e95",  u"\u0ea7",       u"\u0ead" ]
    LaoTCM = [ u"\u0ecb",  u"\u0ecb",   u"\u0ecb",  u"\u0ecb",  u"\u0ecb",       u"\u0ecb",   u"",        u"",          u"\u0ecb",  u"",             u"",        u"",             u"",             u"",             u"",        u"",         u"\u0ecb",  u"\u0ecb",       u"",        u"",         u"\u0ecb",  u"",             u"\u0ecb" ]
    tdCi1  = [ ts['loBO'], ts['loCO'],  ts['loKO'], ts['loYO'], ts['loDO'],      ts['loYO'],  ts['loHO'], ts['loKHHO'], ts['loKO'], ts['loLO'],      ts['loMO'], ts['loNGO'],     ts['loNGO'],     ts['loNYO'],     ts['loNO'], ts['loFO'],  ts['loPO'], ts['loKW'],      ts['loSO'], ts['loTHO'], ts['loTO'], ts['loVO'],      ts['loO'] ]  
    tdCi4  = [ ts['hiBO'], ts['hiCO'],  ts['hiKO'], ts['hiYO'], ts['hiDO'],      ts['hiYO'],  ts['hiHO'], ts['hiKHHO'], ts['hiKO'], ts['hiLO'],      ts['hiMO'], ts['hiNGO'],     ts['hiNGO'],     ts['hiNYO'],     ts['hiNO'], ts['hiFO'],  ts['hiPO'], ts['hiKW'],      ts['hiSO'], ts['hiTHO'], ts['hiTO'], ts['hiVO'],      ts['hiO'] ]

    # Check the VN spelling for potentially ambiguous spellings: "kho" and "ngo".
    # If found, interpret them correctly and return the results.
    # REMEMBER that a dummy glottal stop has been appended to the beginning of the
    # syllable. Adjust all strings and indices accordingly.
    if len(w)>4 and (w[:4]==u"\u0294kho" or w[:4]==u"\u0294ngo"):
        #If the next character is a vowel other than 'i', the 'o' marks labialization
        if u"aeou".find(w[4]) != -1:
            #o is a w
            labialization = 1
        #Esle if the next character is a non-final 'i', the 'o' marks labialization
        elif w[4]=='i' and len(w) > 5:
            #0 is a w
            labialization = 1
        else:
            labialization = 0
        if labialization:
            if w[:3]==u"\u0294kh":      # kho
                if tone>=4:
                    return (u"\u0294kho", u"\u0e84\u0ea7", u"", ts['hiKHHW'])
                else:
                    return (u"\u0294kho", u"\u0e82\u0ea7", u"", ts['loKHHW'])
            else:                       # ngo
                if tone>=4:
                    return (u"\u0294ngo", u"\u0e87\u0ea7", u"", ts['hiNGW'])
                else:
                    return (u"\u0294ngo", u"\u0eab\u0e87\u0ea7", u"", ts['loNGW'])       
    
    # If no ambiguous initial consonant was found, search the Initial Consonant Mapping Table
    # to ID the initial consonant.
    TableLength = len (vnCi)
    i=0
    while i < TableLength:
        if w.startswith(vnCi[i]):
            break
        i=i+1
        
    # If ID failed, word is misspelled.
    if i >= TableLength:
        TypoCount = TypoCount + 1
        return (u"", TYPO+w, u"", TYPO+w)

    # Return the results based on the index of the VN consonant.
    if tone >= 4:
        return (vnCi[i], LaoCi4[i], LaoTCM[i], tdCi4[i])
    else:
        return (vnCi[i], LaoCi1[i], u"", tdCi1[i])

def GetCf(w):
    # Identify and return the Lao and Tai Dam final consonant, and indicate
    # whether or not it is a stop. Assume w contains only the
    # VN final consonant + an ending '#'.

    global TypoCount    

    # FINAL CONSONANT MAPPING TABLE, including a flag to indicate if the Cf is a stop.
    vnCf  = [ u"#", u"ch",      u"c",       u"i",       u"k",       u"m",       u"ng",       u"nh",       u"n",       u"o",       u"u",       u"p",       u"t"       ]
    LaoCf = [ u"",  u"\u0e81",  u"\u0e81",  u"\u0e8d",  u"\u0eb0",  u"\u0ea1",  u"\u0e87",   u"\u0e87",   u"\u0e99",  u"\u0ea7",  u"\u0ea7",  u"\u0e9A",  u"\u0e94"  ]
    tdCf  = [ u"",  ts['loKO'], ts['loKO'], ts['hiYO'], ts['loKO'], ts['hiMO'], ts['hiNGO'], ts['hiNGO'], ts['hiNO'], ts['hiVO'], ts['hiVO'], ts['loBO'], ts['loDO'] ]
    Cst   = [ 0,    1,          1,          0,          1,          0,          0,           0,           0,          0,          0,          1,          1          ]

    # Search the table to ID the final consonant
    TableLength = len (vnCf)
    i=0
    while i < TableLength:
        if w.startswith(vnCf[i]):
            break
        i=i+1

    # Error check -- if i is too big, the Cf could not be identified.
    if i >= TableLength:
        TypoCount = TypoCount + 1
        return (TYPO+w, TYPO+w, 0)

    # Done. Return the results.    
    return (LaoCf[i], tdCf[i], Cst[i])

def GetV (w):
    # Analyse string w and return the parts of the Lao vowel (LaoVi, LaoVd, LaoVf),
    # the Lao final consonant (LaoCf), the parts of the Tai Dam vowel (tdVi, tdVd,
    # tdVf), the Tai Dam final consonant (tdCf) and whether the final C is a stop.
    # Assume w starts with the VN vowel. 
    # First, delete any tone mark to get it out of the way and append a #
    # to the end of w to mark the word boundary. (This enables a search
    # for "vv..#" to locate open syllables.)
    # Second, search the list vnV to identify the VN vowel. Use the resulting
    # index to select the objects that are to be returned.
    # Third, use the index and the list MoreCf to determine whether an addtional
    # search needs to be made to identify the final consonant.

    global TypoCount    

    # VOWEL MAPPING TABLE:
    # The table consists of four parallel lists. The writing of Lao vowels
    # and final consonants is conditioned by how the syllable ends, including final
    # glottal stop, final 'y', final 'w', final 'm', and other closed vs. open
    # syllables.) Consequently, the entries to the table must take all relevent
    # iterations of these features into account.
    #    
    # The comment line labeled "ortho" above the list "vnV is an attempt
    # to clarify the contents of that list. The following orthographic
    # representation is used:
        # /-v#/ represents a vowel + open syllable
        # /-vC/ represents a vowel + character C.  In general, 'k' = glottal stop,
        #       final 'y' or 'i' represents /-j/, final 'o', 'u', or 'u-horn'
        #       represents /-w/.
        # /-v/ represents a vowel + any ending not eliminated by a previous search 
        # "v^" represents a vowel + circumflex
        # "v~" represents a vowel + breve
        # "v'" represents a vowel + horn
    # The order of the entries in the vnV list is critical--it must be searched in
    # the order given to ensure an accurate ID of the vowel.

    # ortho:   /-ie^/       /-ia/      /-ik/       /-i/       /-e^#/       /-e^k/       /-e^/       /-e/       /-u'o'/            /-u'ak/       /-u'a#/       /-u'k/       /-u'/       /-o'k/       /-o'/        /-a~m/       /-a~ng/       /-a~n/     /-a~p/         /-a~/        /-au'/       /-au/       /-ay/      /-ak/        /-a/       /-uo^/       /-ua/      /-u#/      /-uk/       /-u/       /-o^#/       /-o^k/       /-o^/       /-o#/        /-ok/       /-o/
    vnV    = [ u"ie\u0302", u"ia",     u"ik",      u"i",      u"e\u0302#", u"e\u0302k", u"e\u0302", u"e",      u"u\u031bo\u031b", u"u\u031bak", u"u\u031ba#", u"u\u031bk", u"u\u031b", u"o\u031bk", u"o\u031b",  u"a\u0306m", u"a\u0306ng", u"a\u0306n", u"a\u0306p", u"a\u0306",  u"au\u031b", u"au",      u"ay",     u"ak",       u"a",      u"uo\u0302", u"ua",     u"u#",     u"uk",      u"u",      u"o\u0302#", u"o\u0302k", u"o\u0302", u"o#",       u"ok",      u"o"      ]
    LaoVi  = [ u"",         u"\u0ec0", u"",        u"",       u"\u0ec0",   u"\u0ec0",   u"\u0ec0",  u"\u0ec1", u"\u0ec0",         u"\u0ec0",    u"\u0ec0",    u"",         u"",        u"\u0ec0",   u"\u0ec0",   u"",         u"",          u"",       u"",           u"",         u"\u0ec3",   u"\u0ec0",  u"\u0ec4", u"",         u"",       u"",         u"",       u"",       u"",        u"",       u"\u0ec2",   u"\u0ec2",   u"",        u"",         u"\u0ec0",  u""       ]
    LaoVd  = [ u"",         u"\u0eb1", u"\u0eb4",  u"\u0eb5", u"",         u"",         u"\u0eb1",  u"",       u"\u0eb7",         u"\u0eb6",    u"\u0eb7",    u"\u0eb6",   u"\u0eb7",  u"\u0eb4",   u"\u0eb5",   u"",         u"\u0eb1",    u"\u0eb1", u"\u0eb1",     u"\u0eb1",   u"",         u"\u0ebb",  u"",       u"",         u"",       u"",         u"\u0ebb", u"\u0eb9", u"\u0eb8",  u"\u0eb8", u"",         u"",         u"\u0ebb",  u"\u0ecd",   u"",        u""       ]
    LaoVf  = [ u"\u0ebd",   u"\u0ebd", u"",        u"",       u"",         u"",         u"",        u"",       u"\u0ead",         u"\u0ead",    u"\u0ead",    u"",         u"",        u"",         u"",         u"\u0eb3",   u"",          u"",       u"",           u"",         u"",         u"\u0eb2",  u"",       u"",         u"\u0eb2", u"\u0ea7",   u"\u0ea7", u"",       u"",        u"",       u"",         u"",         u"",        u"",         u"\u0eb2",  u"\u0ead" ]
    LaoCf  = [ u"",         u"",       u"",        u"",       u"",         u"\u0eb0",   u"",        u"",       u"",               u"",          u"",          u"",         u"",        u"",         u"",         u"",         u"\u0e87",    u"\u0e99", u"\u0e9a",     u"",         u"",         u"",        u"",       u"\u0eb0",   u"",       u"",         u"",       u"",       u"",        u"",       u"",         u"\u0eb0",   u"",        u"",         u"\u0eb0",  u""       ]
    tdVi   = [ u"",         u"",       u"",        u"",       ts['vUEA'],  ts['vUEA'],  ts['vUEA'], ts['vE'],  ts['vUEA'],        ts['vUEA'],   ts['vUEA'],   u"",         u"",        ts['vUEA'],  ts['vUEA'],  u"",         u"",          u"",       u"",           u"",         ts['vAUE'],  ts['vUEA'], ts['vAY'], u"",         u"",       u"",         u"",       u"",       u"",        u"",       ts['vO'],    ts['vO'],    ts['vO'],   u"",         u"",        u""       ]
    tdVd   = [ ts['vIA'],   ts['vIA'], ts['vI'],   ts['vI'],  ts['vIA'],   ts['vIA'],   ts['vIA'],  u"",       u"",               u"",          u"",          ts['vUE'],   ts['vUE'],  ts['mKHIT'], ts['mKHIT'], ts['vAM'],   ts['mKANG'],  u"",       u"",           ts['mKANG'], u"",         u"",        u"",       u"",         u"",       u"",         u"",       ts['vU'],  ts['vU'],   ts['vU'],  u"",         u"",         u"",        ts['mKHIT'], u"",        u""       ]
    tdVf   = [ u"",         u"",       u"",        u"",       u"",         u"",         u"",        u"",       u"",               u"",          u"",          u"",         u"",        u"",         u"",         u"",         u"",          u"",       u"",           u"",         u"",         ts['vAA'],  u"",       ts['vAA'],   ts['vAA'], ts['vUA'],   ts['vUA'], u"",       u"",        u"",       u"",         u"",         u"",        u"",         ts['loO'],  ts['loO'] ]
    tdCf   = [ u"",         u"",       ts['loKO'], u"",       u"",         ts['loKO'],  u"",        u"",       u"",               ts['loKO'],   u"",          ts['loKO'],  u"",        ts['loKO'],  u"",         u"",         ts['hiNGO'],  ts['vAN'], ts['vAP'],     u"",         u"",         u"",       u"",        ts['loKO'],  u"",       u"",         u"",       u"",       ts['loKO'], u"",       u"",         ts['loKO'],  u"",        u"",         ts['loKO'], u""       ]
    MoreCf = [  1,           1,         0,         1,         0,           0,           1,          1,         1,                 0,            0,            0,           1,          0,           1,           0,           0,            0,         0,             1,           0,           0,         0,          0,           1,         1,           1,         0,         0,          1,         0,           0,           1,          0,           0,          1         ]
    Cst    = [  0,           0,         1,         0,         0,           1,           0,          0,         0,                 1,            0,            1,           0,          1,           0,           0,           0,            0,         1,             0,           0,           0,         0,          1,           0,         0,           0,         0,         1,          0,         0,           1,           0,          0,           1,          0,        ]

    # Delete tone mark and append #
    i=w.find(ACUTE)
    j=w.find(HOOK)
    k=w.find(DOT)
    if i+1:
        w2 = w[:i]+w[i+1:]+u"#"
    elif j+1:
        w2 = w[:j]+w[j+1:]+u"#"
    elif k+1:
        w2 = w[:k]+w[k+1:]+u"#"
    else:
        w2 = w+u"#"

    # Search vnV to identify the VN vowel.
    TableLength = len (vnV)
    i=0
    while i < TableLength:
        if w2.startswith(vnV[i]):
            break
        i=i+1

    # Error check--if i is too large, nothing has been found.
    if i >= TableLength:
        TypoCount = TypoCount + 1
        return (u"", u"", TYPO+w, u"", u"", u"", TYPO+w, u"", 0)

    # Do we need to do more searching for the final consonant?
    if MoreCf[i]:
        LaoCf2, tdCf2, stopped = GetCf(w2.lstrip(vnV[i]))
    else:
        LaoCf2 = LaoCf[i]
        tdCf2 = tdCf[i]
        stopped = Cst[i]

    # Done. Return the results.    
    return (LaoVi[i], LaoVd[i], LaoVf[i], LaoCf2, tdVi[i], tdVd[i], tdVf[i], tdCf2, stopped)

def GetToneMarks (tone, stopped):
    # Return the correct tone marks, including:
    #   - the Lao combining tone
    #   - the Tai Dam combining tone
    #   - and Tai Dam spacing tone.

    if stopped:
        return(u"", u"", u"")                # no tone mark for stopped syllables
    else:
        if tone==6 or tone==3:
            return (u"\u0ec9", ts['mTHO'], ts['mSONG'])      # Mai Tho/Song for tones 3 & 6
        elif tone==5 or tone==2:
            return (u"\u0ec8", ts['mEK'], ts['mNUENG'])      # Mai Ek/Nueng for tones 2 & 5
        else: # tone 4 or 1
            return (u"", u"", u"")            # no tone mark for tones 1 & 4

def FindEndMarker (line, e):
    # 'line' starts with a SFM marker. Find the end of the marker.
    e=e+1
    while True:
        ## print line
        if line[e] == u'\n':
            break
        if line[e] == u'\\':
            e = FindEndMarker(line, e)
        if line[e].isspace():
            break
        e = e+1
    return(e)

def FindEndBoundary (line, e):
    # 'line' starts with a syllable boundary. Find the end of the boundary (i.e. the beginning
    # of the next syllable. 
    # The boundary may contain a footnote marker or other inline format marker.
    while True:
        ## print line
        if line[e] == u'\n':
            break
        if line[e] == u'\\':
            e = FindEndMarker(line, e)
        if isVNalpha(line[e]):
            break
        e = e+1
    return(e)

def CheckBoundary (b):
    # There are two possible adjustments which may need to be made to the boundary:
    #   --  VN uses a syllable-boundary hyphen between syllables of words (mostly
    #       names). Lao and Tai Dam do not.  If the boundary is an SBH, remove it.
    #   --  Check the punctuation dictionary to see if punctuation needs to be changed.
    # Return strings for both the Lao and Tai Dam boundary.

    global PunctLex, SBH
    
    # First check for the syllable break.    
    if b == SBH:
        return (u"", u"")

    # Then check the punctuation dictionary.
    # How many records are in the dictionary?
    LexLength = len (PunctLex)
    # Check each record...
    for i in range (0, LexLength):
        # Search for the vn punctuation in the boundary.
        j = b.find(PunctLex[i].vn)
        # A valid index (j) indicates that the punctuation was found and where it starts...
        if j > -1:
            # Set index (k) to where the punctuation string ends.
            k = j + len(PunctLex[i].vn)
            # Build the new boundary for both alphabets; each new boundary consists of:
            #     b up to the replaced punctuation
            #   + the replacement punctuation
            #   + the remainder of b after the punctuation
            lb = b[:j] + PunctLex[i].lao + b[k:]
            tb = b[:j] + PunctLex[i].td + b[k:]
            return (lb, tb)
    # If the dictionary search completes without making a match, return
    # the original boundary.
    return (b, b)

def transliterate (Word, Boundary):
    # Transliterate the one-word string, s.  It may be assumed that s
    # consists only of alphabetic characters (as defined by isVNalpha).

    global TypoCount, LastLaoWord, LastTdWord, LastBoundary    

    # Convert everything to lower case for easier parsing.
    Word1 = Word.lower()

    # Check for dictionary substitution.
    LaoWord, tdWord = CheckSpExLex (Word1)

    # Either CheckSpExLex will return valid words for both LaoWord and tdWord, or both will be  
    # null. Check the LaoWord, and if it is null, apply the Lao and TD spelling rules.
    if LaoWord==u"":
##        print "Word:", Word

        # Get the tone number.
        ToneNumber = GetToneNumber(Word1)
##        print "ToneNumber:", ToneNumber
        # Check the tone number for errors.
        if ToneNumber == -1:
            TypoCount = TypoCount + 1
            return (TYPO+Word)

        # Get the Lao and TD Initial Consonant and Lao TCM.
        # This requires stripping the VN TCM and appending a glottal stop to the beginning
        # of the word.
        # Also get the VN Ci so it can be stripped before getting the vowels.
        Word2 = u"\u0294" + Word1.lstrip(TCM)
        vnCi, LaoCi, LaoTCM, tdCi= GetCi(Word2, ToneNumber)

        # Get the vowel parts and final Consonant. This requires stripping off the VN Ci,
        # including the glottal stop that was appended in the previous step.
        Word3 = Word2.lstrip(vnCi)
        LaoVi, LaoVd, LaoVf, LaoCf, tdVi, tdVd, tdVf, tdCf, stopped = GetV (Word3)

        # Get the Lao and TD tone mark.
        if Boundary==SBH or LastBoundary==SBH:
            # Non-breaking Hyphens flag names; omit tone from names
            LaoTone = u""
            LaoTCM = u""
            tdCombiningTone = u""
            tdSpacingTone = u""
        else:
            LaoTone, tdCombiningTone, tdSpacingTone = GetToneMarks (ToneNumber, stopped)
##        # U+0294 was used to flag that a final glottal stop is inherent in the vowel. It is no
##        # longer needed as a flag.
##        if LaoCf == u"\u0294":
##            LaoCf = u""

        # Build the Lao and TD words.
##        print "Vi:", LaoVi, "Ci", LaoCi, "Vd:", LaoVd, "T:", LaoTone, "TCM:", LaoTCM, "Vf:", LaoVf, "Cf:", LaoCf
        LaoWord = LaoVi + LaoCi + LaoVd + LaoTone + LaoTCM + LaoVf + LaoCf
        if UseMaiNueng:
            tdWord = tdVi + tdCi + tdVd + tdVf + tdCf + tdSpacingTone
        else:
            tdWord = tdVi + tdCi + tdVd + tdCombiningTone + tdVf + tdCf

    # Check for reduplication
    if LaoWord!=u"" and LaoWord==LastLaoWord and (LastBoundary==u" " or LastBoundary==NBSP):
        LaoWord = u"\u0ec6"         # insert Reduplication symbol
    LastLaoWord = LaoWord
    if tdWord!=u"" and tdWord==LastTdWord and (LastBoundary==u" " or LastBoundary==NBSP):
        tdWord = ts['symSAM']       # insert Reduplication symbol
    LastLaoWord = LaoWord
    LastTdWord = tdWord
    LastBoundary = Boundary

    # If the boundary is a non-breaking hyphen, remove it.
    LaoBoundary, tdBoundary = CheckBoundary (Boundary)
##    print "Word =", LaoWord, "Boundary =", LaoBoundary

    return(LaoWord, LaoBoundary, tdWord, tdBoundary)

def IniTest(IniSpec):
    # Display the programs variables that can be set in the command line and
    # the INI file, and then sign off.

    global PunctLex, SpExLex
    
    # Start with command line variables
    print 'INI file name: ', IniSpec
    print 'Target Alpabets: ', target

    # Then the variables from the INI file.     
    l = len(IgnoredFields)
    print 'Ignored Fields: ',
    for i in range (0, l):
        print IgnoredFields[i],
    print
    print 'Unidentified text will be converted to: ', hex(ord(TYPO))
    print 'Tone Class Marker: ', hex(ord(TCM))
    print 'Syllable-break hyphen: ', hex(ord(SBH))
    print 'No-break Space: ', hex(ord(NBSP))
    if ts['mKANG'] == ts['mKHIT']:
        print 'Short A converted to Mai Khit'
    else:
        print 'Short A converted to Mai Kang'
    if UseMaiNueng:
        print 'Tai Dam tones use Mai Nueng and Mai Song'
    else:
        print 'Tai Dam tones use Mai Ek and Mai Tho'
    print
    
    # Then print the Punctuation Dictionary
    l = len(PunctLex)
    print 'The punctuation dictionary has', l, 'entries'
    for i in range (0,l):
        vn = UniStr(PunctLex[i].vn)
        lao = UniStr(PunctLex[i].lao)
        td = UniStr(PunctLex[i].td)
        print 'VN:', vn, '  LAO:', lao, '  TD:', td
    print
    
    # Then print the Spelling Exceptions Dictionary
    l = len(SpExLex)
    print 'The Spelling Exceptions dictionary has', l, 'entries'
    for i in range (0,l):
        vn = UniStr(SpExLex[i].vn)
        lao = UniStr(SpExLex[i].lao)
        td = UniStr(SpExLex[i].td)
        print 'VN:', vn, '  LAO:', lao, '  TD:', td
    print

    SignOff ('End of INI test.')

def UniStr (uString):
    # Convert Unocide string 'uString' into an ascii representation in which
    # characters above U+00ff are represented by the escape sequence '\uXXXX'
    aString = ''
    l = len(uString)
    for i in range (0,l):
        o = ord(uString[i])
        if o < 128:
            aString = aString + uString[i]
        else:
            h = hex(o)[2:]
            while len(h) < 4:
                h = '0' + h
            aString = aString + '\\u' + h
    return(aString)
    
def SignOff (message):
    print "syntax:  TDoc [-i IniFileName] [-t TargetAlphabets] [-test] InputFile"
    print "or:      TDoc [-wpx] [-t TargetAlphabets] [-test] InputFile"
    print
    print message
    print
    raw_input ("Press <Enter> to exit.")
    sys.exit()


#################################################
# Class definitions.
#################################################
class Segment:
# After a line is read from input, it is broken down into a linked list of segments. Each
# segment consists of an optional word + a required boundary.  "Word" is used here as a logical
# concept. It is defined as a string of those alphabetic characters defined by isVNalpha, but will
# usually correspond to an orthographic word or syllable. The boundary consists of the string
# of those characters that are not defined by isVNalpha, and which follow the word and divide it
# from the next segment.  When a line starts with a format marker or punctuation, the first segment
# of the line will contain a boundary but not a word. (I.e. the format marker or leading punctuation
# is all part of the boundary.)

    # The Segment constructor builds the linked list of Segments from the line.
    def __init__(self, line):
        #Have we reached the end of line?
        if line[0]=='\n':
            self.word = ''
            self.boundary = line
            return

        #The word starts at 0.  Find i, the start of tbe boundary, and j, the end of the boundary.
        i=0
        #Check for SFM
        if line[0]=='\\':
            # The line starts with an SFM. Thus, the word for this iteration is null,
            # and i remains at 0.
            # Find end of marker.
            j = FindEndMarker(line, i)
            #Then find end of boundary (beginning of next word).
            j = FindEndBoundary(line, j)
            #j now marks the end of the boundary. 
        else:
##            print "entering first while loop"
##            print "length = ", len(line)
##            print "last two chars = ", line[-2], line[-1]
            # Text is a normal segment. First check for a TCM.
            if line[i]==TCM:
                i=i+1
            # Then find the end of the current word.
            while isVNalpha(line[i]) and line[i]!=TCM:
##                print "i = ", i, ";  line[i] = ", line[i]
                i=i+1
            #Then find end of boundary (beginning of next word).
            j = FindEndBoundary(line, i)

        # i now points to the beginning of the boundary (end of the word)
        # j points to the end of the boundary (beginning of next word)
        # But if i points to a TCM, we have a syllable break without a hyphen. Insert
        # the SBH into the boundary as a temporary flag.
        self.word = line[:i]
        if line[i] == TCM:
            self.boundary = SBH
        else:
            self.boundary = line[i:j]
        self.SegmentList = Segment(line[j:])
        return

    #The TranslitWord method transliterates words into the alternate orthography
    def TranslitWord (self):
        if self.boundary == '\n':
            self.LaoWord = ''
            self.LaoBoundary = self.boundary
            self.tdWord = ''
            self.tdBoundary = self.boundary
        elif self.word==u"":
            self.LaoWord = self.word
            self.LaoBoundary = self.boundary
            self.tdWord = self.word
            self.tdBoundary = self.boundary
            self.SegmentList.TranslitWord()
        else:
            self.LaoWord, self.LaoBoundary, self.tdWord, self.tdBoundary = transliterate (self.word, self.boundary)
            self.SegmentList.TranslitWord()
        return

    #Output the word list as a line
    def OutputWord (self):
        global laofile, tdfile
        if doLao:
            laofile.write (self.LaoWord)
            laofile.write (self.LaoBoundary)
        if doTD:
            tdfile.write (self.tdWord)
            tdfile.write (self.tdBoundary)
        if self.boundary == '\n':
            return
        else:
            self.SegmentList.OutputWord()
            return

    #End of Segment class

class LexItem:
# A lexical item consists of three fields containing a word, phrase, or punctuation
# in the three orthographies: vn, td, and lao

    global TYPO

    # A new LexItem is created whenever a \vn line is found in the initialization file. 
    # The contents of the \vn line is passed to the new LexItem, whose constructor
    # initiates the vn field. The constructor also creates td and lao fields and
    # initiates them to TYPO (the default replacement character).
    def __init__(self, Word):
        self.vn = Word
        self.td = TYPO
        self.lao = TYPO
        self.check_self()
        
    # A method is needed to assign data to the td and lao lexical fields.
    def set_td(self, Word):
        self.td = Word
        self.check_self()
    def set_lao(self, Word):
        self.lao = Word
        self.check_self()
        
    # Another method checks to see if the td and lao fields have been assigned valid
    # replacement strings.
    def check_self(self):
        self.valid = (self.td<>TYPO and self.lao<>TYPO)

    # End of LexItem class

    
#####################################################
# Main.
#####################################################

# Sign on
print "Tai Dam Orthography Converson program, version ", Version

# Read the Com line arguements.
ScriptPath, iniPath, iniNameExt, inPath, inName, inExt = ReadComLine (sys.argv)
##print ScriptPath
##print iniPath, iniNameExt
##print target
##print inPath, inName, inExt

# Read Initialization File.
if iniNameExt.lower()!="none":
    if iniNameExt=="":
        iniNameExt = "TDoc-ini.txt"

    paths = [iniPath, inPath, ScriptPath ]
    n = len (paths)
    iniFound=0
    i=0
    while i < n:
        FileSpec = paths[i]+iniNameExt
        try:
            inifile = codecs.open (FileSpec, "r", "utf-8")
        except IOError:
            i=i+1
            continue
        iniFound=1
        break
    if iniFound:
        # ReadIniFile reads the file, verifies that it is good,
        # and closes the file. 
        ReadIniFile(inifile)
    else:
        SignOff ("Unable to find INI file: " + iniNameExt)


# Evaluate the target alphabet(s)
##print "target =", target
if target.lower() == "both":
    doLao = 1
    doTD = 1
elif target.lower() == "taidam":
    doLao = 0
    doTD = 1
elif target.lower() == "lao":
    doLao = 1
    doTD = 0
else:
    SignOff ("No target alphabet(s) designated. Check the command line and the INI file.")

# if the test flag has been set, display the program initialization info
if doIniTest:
    IniTest(FileSpec)

# if no input file has been specified, print the command line syntax and exit
if inName == "":
    SignOff ("No input file specified")

# Open i/o files.
inSpec  = inPath+inName+inExt
laoSpec = inPath+inName+"-L"+inExt
tdSpec  = inPath+inName+"-T"+inExt
try:
    infile = codecs.open (inSpec, "r", "utf-8")
except IOError:
    SignOff ("Unable to find input file: " + inSpec)
if doLao:
    laofile = codecs.open (laoSpec, "w", "utf-8")
if doTD:
    tdfile = codecs.open (tdSpec, "w", "utf-8")

# Read lines from input one at a time until EOF. Normalize the line to NFD.
while 1:
    line = unicodedata.normalize("NFD",infile.readline())
    length = len(line)
    if length==0:
        break

    #If the first character a BOM, write the BOM to the output, and
    #increment past it.
    i=0
    if line[i] == u'\uFEFF':
        if doLao:
            laofile.write (line[i])
        if doTD:
            tdfile.write (line[i])
        i=i+1

    #Is this an ignored field?
    if isIgnoredField(line[i:]):
        if doLao:
            laofile.write (line[i:])
        if doTD:
            tdfile.write (line[i:])
        continue

    # Divide the line into segments.
    SegmentList = Segment(line[i:])

    # Transliterate the segments.
    SegmentList.TranslitWord()

    # Write the transliterated segments to the output
    SegmentList.OutputWord()

# Report Typos
if TypoCount > 0:
    print TypoCount, "word(s) from the source text could not be parsed."
    print "These have been flagged in the output with the TypoFlag character U+", hex(ord(TYPO))[2:]

# Close i/o files.
if doLao:
    laofile.close()
if doTD:
    tdfile.close()
infile.close()
