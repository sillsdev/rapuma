#!/bin/sh

# Simple control script for running text transcoding for the Tai Dam publishing project

# Set our input files
input_file="$1"
output_file="$2"
init_file="$3"
target_lang="$4"
punctuation_map="$5"

# Move to the command section of the input
shift 2

# Create some temporary files
tmp_area=$(mktemp -t -d "ptxplus-proc.XXXX") || exit 1
# Set error trapping in case there is a failure
trap "rm -rf -- $tmp_area; exit" HUP INT PIPE TERM EXIT

# Create tmp_file
tmp1=$tmp_area/temp_1

# Do the initial transcription
echo python Encoding/TDoc2_01.py -i $init_file -t $target_lang -o $tmp1 $input_file
python Encoding/TDoc2_01.py -i $init_file -t $target_lang -o $tmp1 $input_file

# Add the right punctuation markup
echo txtconv -t $punctuation_map -i $tmp1 -o $output_file
txtconv -t $punctuation_map -i $tmp1 -o $output_file


