#!/bin/sh

# Commands for creating the KYU-MYMR-MRK test project.


# Remove the project (if needed)
rapuma project KYU-MYMR-MRK -r

# Create a fresh project
rapuma project KYU-MYMR-MRK -m book -a -n "Kayah NT Book of Mark (Burmese script)" -p "../"

# Add customized style files
rapuma style KYU-MYMR-MRK usfm main -a -p "bible-format.sty"
rapuma style KYU-MYMR-MRK usfm custom -a -p "custom.sty"

# Add the primary component
rapuma component KYU-MYMR-MRK usfm mark -a -s "../pt_environ" -i mrk

# Add/overwrite default project files with special ones
rapuma install -f KYU-MYMR-MRK "mrk.adj" "../KYU-MYMR-MRK/Components/mark"

# Set Padauk as the main font (not sure why we need to do this)
rapuma font KYU-MYMR-MRK usfm Padauk_2.701 -m -f

# Adjust exsisting settings (configuration/section/key/value)
rapuma settings KYU-MYMR-MRK usfm_Layout Fonts lineSpacingFactor 1.0871
rapuma settings KYU-MYMR-MRK usfm_Layout Fonts fontSizeUnit .95pt

# Column Settings
rapuma settings KYU-MYMR-MRK usfm_Layout Columns bodyColumns 2
rapuma settings KYU-MYMR-MRK usfm_Layout Columns columnGutterFactor 10
rapuma settings KYU-MYMR-MRK usfm_Layout Columns columnShift 5.3
rapuma settings KYU-MYMR-MRK usfm_Layout Columns columnGutterRuleSkip 4
rapuma settings KYU-MYMR-MRK usfm_Layout Columns columnGutterRule True

# Page settings
rapuma settings KYU-MYMR-MRK usfm_Layout PageLayout pageSizeCode UBS60
rapuma settings KYU-MYMR-MRK usfm_Layout PageLayout pageWidth 145
rapuma settings KYU-MYMR-MRK usfm_Layout PageLayout pageHeight 210

# Chapter Verse settings
rapuma settings KYU-MYMR-MRK usfm_Layout ChapterVerse useMarginalVerses True
rapuma settings KYU-MYMR-MRK usfm_Layout ChapterVerse afterVerseSpaceFactor 4
rapuma settings KYU-MYMR-MRK usfm_Layout ChapterVerse afterChapterSpaceFactor ""

# Footnote settings
rapuma settings KYU-MYMR-MRK usfm_Layout Footnotes defineFootnoteRule "\hrule height 0.4pt\smallskip"
rapuma settings KYU-MYMR-MRK usfm_Layout Footnotes autoCallerListFootnotes "\kern0.2em *\kern0.4em"
rapuma settings KYU-MYMR-MRK usfm_Layout Footnotes paragraphedFootnotes True
rapuma settings KYU-MYMR-MRK usfm_Layout Footnotes omitCallerInFootnotes True

# Extra settings
rapuma settings KYU-MYMR-MRK usfm_Layout TeXBehavior hFuzz 2pt
rapuma settings KYU-MYMR-MRK usfm_Layout TeXBehavior vFuzz 4.3pt
rapuma settings KYU-MYMR-MRK project usfm_Illustration useIllustrations True

# Font settings
rapuma settings KYU-MYMR-MRK font "Fonts/Charis SIL_4.106/UsfmTeX/SecondaryFont" charissiltitle "\font\charissiltitle = \"[^^path^^/CharisSILI.ttf]\" at 10pt"
rapuma settings KYU-MYMR-MRK font "Fonts/Charis SIL_4.106/UsfmTeX/SecondaryFont" callerfont "\font\callerfont = \"[^^path^^/CharisSILR.ttf]\" at 8pt"
rapuma settings KYU-MYMR-MRK project "Managers/usfm_Font" useLanguage kyu
rapuma settings KYU-MYMR-MRK project "Managers/usfm_Font" useMapping kye_renumber
rapuma settings KYU-MYMR-MRK project "Managers/usfm_Font" useRenderingSystem GR

# Header Content settings
rapuma settings KYU-MYMR-MRK usfm_Layout HeaderContent runningHeaderOddRight lastref
rapuma settings KYU-MYMR-MRK usfm_Layout HeaderContent runningHeaderOddCenter pagenumber
rapuma settings KYU-MYMR-MRK usfm_Layout HeaderContent runningHeaderEvenLeft firstref
rapuma settings KYU-MYMR-MRK usfm_Layout HeaderContent runningHeaderEvenCenter pagenumber
rapuma settings KYU-MYMR-MRK usfm_Layout HeaderFooter useRunningHeaderRule False
rapuma settings KYU-MYMR-MRK usfm_Layout HeaderFooter headerPosition 0.75
rapuma settings KYU-MYMR-MRK usfm_Layout HeaderFooter runningHeaderRulePosition 4
rapuma settings KYU-MYMR-MRK usfm_Layout HeaderFooter footerPosition 0.12



